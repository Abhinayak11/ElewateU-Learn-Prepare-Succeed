import type { Config } from "tailwindcss";
import { fontFamily } from "tailwindcss/defaultTheme";

const config = {
    darkMode: ["class"],
    content: [
        "./pages/**/*.{ts,tsx}",
        "./components/**/*.{ts,tsx}",
        "./app/**/*.{ts,tsx}",
        "./src/**/*.{ts,tsx}",
    ],
    prefix: "",
    theme: {
        container: { // Ensure container has default padding
            center: true,
            padding: "2rem",
            screens: {
                "2xl": "1400px",
            },
        },
        extend: {
             fontFamily: {
                 sans: ["var(--font-inter)", ...fontFamily.sans], // Ensure Inter font is primary sans font if used via layout
            },
            colors: {
                 // Shadcn UI relies on these variables, defined in globals.css
                 border: "hsl(var(--border))",
                 input: "hsl(var(--input))",
                 ring: "hsl(var(--ring))",
                 background: "hsl(var(--background))",
                 foreground: "hsl(var(--foreground))",
                 primary: {
                   DEFAULT: "hsl(var(--primary))",
                   foreground: "hsl(var(--primary-foreground))",
                 },
                 secondary: {
                   DEFAULT: "hsl(var(--secondary))",
                   foreground: "hsl(var(--secondary-foreground))",
                 },
                 destructive: {
                   DEFAULT: "hsl(var(--destructive))",
                   foreground: "hsl(var(--destructive-foreground))",
                 },
                 muted: {
                   DEFAULT: "hsl(var(--muted))",
                   foreground: "hsl(var(--muted-foreground))",
                 },
                 accent: {
                   DEFAULT: "hsl(var(--accent))",
                   foreground: "hsl(var(--accent-foreground))",
                 },
                 popover: {
                   DEFAULT: "hsl(var(--popover))",
                   foreground: "hsl(var(--popover-foreground))",
                 },
                 card: {
                   DEFAULT: "hsl(var(--card))",
                   foreground: "hsl(var(--card-foreground))",
                 },
            },
             borderRadius: {
               lg: "var(--radius)",
               md: "calc(var(--radius) - 2px)",
               sm: "calc(var(--radius) - 4px)",
             },
            keyframes: {
                "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
                "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
                "fade-in": { "0%": { opacity: "0" }, "100%": { opacity: "1" } },
                "fade-in-down": { "0%": { opacity: "0", transform: "translateY(-20px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
                "fade-in-up": { "0%": { opacity: "0", transform: "translateY(20px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
                "pulse": { "50%": { opacity: ".5" } },
            },
            animation: {
                "accordion-down": "accordion-down 0.2s ease-out",
                "accordion-up": "accordion-up 0.2s ease-out",
                "fade-in": "fade-in 0.8s ease-out 0.4s forwards",
                "fade-in-down": "fade-in-down 0.6s ease-out forwards",
                "fade-in-up": "fade-in-up 0.6s ease-out 0.2s forwards",
                "pulse": "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
            },
        },
    },
    // Ensure only necessary plugins are included
    plugins: [require("tailwindcss-animate")],
} satisfies Config;

export default config;

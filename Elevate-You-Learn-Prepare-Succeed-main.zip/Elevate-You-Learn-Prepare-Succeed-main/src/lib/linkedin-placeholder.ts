export default {
  "firstName": "John",
  "lastName": "Doe",
  "headline": "Experienced Software Engineer | Full Stack Developer",
  "email": "john.doe@email.com",
  "phone": "+1-555-123-4567",
  "location": "San Francisco Bay Area",
  "summary": "Highly motivated and results-driven software engineer with over 5 years of experience in full-stack web development. Proficient in React, Node.js, and various cloud technologies. Passionate about building scalable and user-friendly applications.",
  "education": [
    {
      "schoolName": "University of California, Berkeley",
      "degree": "Master of Science",
      "fieldOfStudy": "Computer Science",
      "startYear": 2016,
      "endYear": 2018
    },
    {
      "schoolName": "Stanford University",
      "degree": "Bachelor of Science",
      "fieldOfStudy": "Computer Engineering",
      "startYear": 2012,
      "endYear": 2016
    }
  ],
  "experience": [
    {
      "companyName": "Tech Innovations Inc.",
      "title": "Senior Software Engineer",
      "location": "San Francisco, CA",
      "startDate": "2019-07-01",
      "endDate": null,
      "description": "Led the development of key features for our flagship web application. Mentored junior developers and improved team development practices. Worked with React, Node.js, AWS, and microservices architecture."
    },
    {
      "companyName": "Web Solutions Corp.",
      "title": "Software Engineer",
      "location": "Mountain View, CA",
      "startDate": "2018-08-01",
      "endDate": "2019-06-30",
      "description": "Developed and maintained web applications using JavaScript, HTML, CSS, and various frontend frameworks. Collaborated with cross-functional teams to deliver high-quality software products."
    }
  ],
  "skills": [
    "JavaScript",
    "React",
    "Node.js",
    "HTML",
    "CSS",
    "AWS",
    "Git",
    "SQL",
    "NoSQL",
    "RESTful APIs",
    "Agile Development",
    "TypeScript"
  ],
  "certifications": [
    {
      "name": "AWS Certified Solutions Architect - Associate",
      "issuingOrganization": "Amazon Web Services",
      "issueDate": "2020-05-15",
      "expirationDate": "2023-05-15"
    },
    {
        "name": "Certified ScrumMaster",
        "issuingOrganization": "Scrum Alliance",
        "issueDate": "2019-10-10",
        "expirationDate": null
    }
  ],
  "projects": [
    {
      "name": "Personal Portfolio Website",
      "description": "Developed a responsive and dynamic portfolio website to showcase my skills and projects.",
      "startDate": "2021-01-01",
      "endDate": "2021-03-30",
      "url": "https://www.johndoeportfolio.com"
    },
    {
        "name": "E-commerce Platform",
        "description": "Developed an e-commerce platform with user authentication, product catalog, shopping cart, and payment integration.",
        "startDate": "2020-05-01",
        "endDate": "2020-12-30",
        "url": "https://www.ecommerceplatform.com"
    }
  ]
};

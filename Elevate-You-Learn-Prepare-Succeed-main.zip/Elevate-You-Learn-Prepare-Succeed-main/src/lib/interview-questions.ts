
/*
 * @fileOverview Stores the fixed interview questions for different career paths.
 */

// Keep the type locally for the keys, but don't export it if only used here.
type CareerPath =
    | "Software Engineer"
    | "Data Scientist"
    | "Product Manager"
    | "UX Designer"
    | "DevOps Engineer"
    | "Cloud Computing";

type CareerPathExtended =
  | CareerPath
  | 'frontend'
  | 'backend'
  | 'fullstack'
  | 'data-science'
  | 'devops';

// Define the fixed questions for each career path (MAX 5 QUESTIONS PER PATH)
// Ensure all questions are valid strings. 
export const INTERVIEW_QUESTIONS_BANK: Record<CareerPathExtended, string[]> = {
  "Software Engineer": [
    "What is your experience with different programming languages and which one do you prefer?",
    "Can you describe a challenging bug you encountered and how you resolved it?",
    "How do you ensure code quality and maintainability in your projects?",
    "Explain the concept of object-oriented programming (OOP) and its principles.",
    "Describe your approach to designing and implementing software architectures."
  ],
    "Data Scientist": [
      "What are the key differences between data mining, data analysis, and machine learning?",
      "How do you handle imbalanced datasets?",
      "Describe a time when you had to present data-driven insights to a non-technical audience.",
      "What are your go-to tools for data preprocessing and cleaning?",
      "How do you approach feature engineering in a new dataset?"
    ],
    "Product Manager": [
      "How do you prioritize features and manage a product roadmap?",
      "Describe your process for conducting market research and understanding customer needs.",
      "How do you measure the success of a product feature or launch?",
      "What strategies do you use to gather user feedback and iterate on product design?",
      "Explain your experience with Agile or other project management methodologies."
    ],
    "UX Designer": [
      "What is your design process for creating user interfaces?",
      "How do you conduct user research and usability testing?",
      "Describe your familiarity with different design tools and prototyping methods.",
      "What are the key principles of good user interface design?",
      "How do you handle accessibility in your design work?"
    ],
    "DevOps Engineer": [ "What is your experience with automation and scripting?", "How do you handle infrastructure scaling and optimization?", "Describe your experience with monitoring and logging tools.", "How do you ensure the security of a DevOps pipeline?", "What is your approach to disaster recovery and business continuity?"],
    "Cloud Computing": ["What cloud platforms have you worked with?", "Describe your experience with containerization and orchestration.", "How do you handle security in cloud environments?", "What is your experience with serverless computing?", "How do you manage cost optimization in the cloud?"],
    "frontend": [
    "Tell me about yourself",
    "How does the virtual DOM work in React, and why is it important?",
    "Can you explain the box model in CSS and how padding, border, and margin interact?",
    "What are the main differences between client-side rendering and server-side rendering?",
    "How do you optimize the performance of a web page?"
  ],
  "backend": [
    "Explain the concept of RESTful APIs and their design principles.",
    "Describe your experience with database management systems (SQL or NoSQL).",
    "How do you handle authentication and authorization in a backend application?",
    "What are the benefits of using a microservices architecture?",
    "Explain the role of middleware in a backend framework like Express.js.",
    "Describe your experience with a specific backend framework (e.g., Node.js, Django).",
    "How do you ensure the security of a backend application?",
    "What are the different types of database relationships?",
    "Explain the concept of caching and its importance in backend development.",
    "How do you monitor and optimize the performance of a backend application?"
  ],
  "fullstack": [
    "Describe your experience building both frontend and backend components.",
    "What are the advantages and disadvantages of microservices vs. monolithic architecture?",
    "How do you ensure the security of a web application?",
    "Explain the difference between SQL and NoSQL databases with examples.",
    "Tell me about integrating a third-party API into an application.",
    "How do you manage a database schema across multiple environments?",
    "Describe your experience with containerization tools like Docker.",
    "What are the best practices for writing scalable code?",
    "How do you test a full-stack application?",
    "Explain the challenges of deploying a full-stack application."
  ],
  "data-science": [
    "Describe a data science project you're proud of. What was the goal, your approach, and the outcome?",
    "Explain the difference between supervised and unsupervised learning, and provide an example algorithm for each.",
    "How do you handle missing or messy data in a dataset?",
    "What are your favorite data visualization libraries and why?",
    "Discuss a potential ethical consideration in a data science project.",
    "How do you validate a machine learning model?",
    "What is the curse of dimensionality, and how do you address it?",
    "Explain the difference between bias and variance in machine learning.",
    "What are the advantages and disadvantages of different machine learning algorithms?",
    "Describe your experience with statistical modeling techniques."
  ],
  "devops": [
    "Explain the concepts of Continuous Integration (CI) and Continuous Deployment (CD).",
    "Describe your experience with containerization (e.g., Docker) and orchestration (e.g., Kubernetes).",
    "How would you monitor the health and performance of a production application?",
    "What is Infrastructure as Code (IaC) and what tools have you used?",
    "How do you approach security in a DevOps pipeline?",
    "Describe your experience with configuration management tools (e.g., Ansible, Chef).",
    "How do you handle rollback and recovery in a production environment?",
    "Explain the benefits of using a microservices architecture in a DevOps context.",
    "What are some best practices for managing secrets in a DevOps pipeline?",
    "Describe your experience with cloud computing platforms (AWS, Azure, GCP)."
  ],

};

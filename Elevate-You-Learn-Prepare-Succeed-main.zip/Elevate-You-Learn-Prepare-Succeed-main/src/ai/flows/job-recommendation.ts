'use server';
/**
 * @fileOverview A job recommendation service (currently using mock data).
 *
 * - recommendJobs - A function that recommends jobs based on course and skills.
 * - RecommendJobsInput - The input type for the recommendJobs function.
 * - RecommendJobsOutput - The return type for the recommendJobs function.
 */

import { z } from 'genkit'; // Keep zod for schema definition
import { JobListing, JobFilter } from '@/services/jobs'; // Import interfaces from service

// Input schema definition (used by the component)
const RecommendJobsInputSchema = z.object({
  course: z.string().describe('The course the user has selected (e.g., Any, Full Stack Development).'),
  skills: z.array(z.string()).describe('The skills the user has listed (e.g., ["React", "Node.js"]).'),
  filter: z
    .object({
      location: z.string().optional().describe('Location filter (always "India" in current use).'),
      experienceLevel: z
        .string()
        .optional()
        .describe('The experience level to filter jobs by (e.g., "Entry Level", "Mid Level").'),
      remote: z.boolean().optional().describe('Whether to filter for remote jobs only.'),
    })
    .optional()
    .describe('Filtering options for the job search.'),
});
export type RecommendJobsInput = z.infer<typeof RecommendJobsInputSchema>;

// Output schema defines the structure of a single job listing
const JobListingSchema = z.object({
    jobTitle: z.string().describe('The title of the job.'),
    companyName: z.string().describe('The name of the company offering the job.'),
    shortDescription: z.string().describe('A brief description of the job.'),
    applyUrl: z.string().describe('The URL to apply for the job.'),
    location: z.string().optional().describe('The primary location of the job (e.g., "Bangalore", "Remote (India)").'),
    isRemote: z.boolean().optional().describe('Flag indicating if the job is remote.'),
    experienceLevel: z.string().optional().describe('The target experience level for the job.'),
});

// Output schema is an array of job listings
const RecommendJobsOutputSchema = z.array(JobListingSchema);
export type RecommendJobsOutput = z.infer<typeof RecommendJobsOutputSchema>;

// Mock job listings specifically for India
// Ensure these match the JobListing interface/schema
const MOCK_INDIA_JOBS: JobListing[] = [
    {
      jobTitle: 'Software Engineer (Sample)',
      companyName: 'Sample Tech India',
      shortDescription: 'Develop backend services and APIs for our platform. Based in Bangalore.',
      applyUrl: '#',
      location: 'Bangalore',
      isRemote: false,
      experienceLevel: 'Entry Level',
    },
    {
      jobTitle: 'Frontend Developer - React (Sample)',
      companyName: 'Sample Solutions Ltd.',
      shortDescription: 'Build responsive user interfaces using React and Tailwind CSS. Join our Hyderabad team.',
      applyUrl: '#',
      location: 'Hyderabad',
      isRemote: false,
      experienceLevel: 'Mid Level',
    },
    {
      jobTitle: 'Data Analyst (Sample)',
      companyName: 'Sample Insights Hub',
      shortDescription: 'Analyze data, generate reports, and provide insights. Python and SQL required. Location: Pune.',
      applyUrl: '#',
      location: 'Pune',
      isRemote: false,
      experienceLevel: 'Mid Level',
    },
    // Add more mocks here if needed, but only the first 3 will be returned
    {
      jobTitle: 'Project Manager - Tech (Sample)',
      companyName: 'Sample Projects India',
      shortDescription: 'Manage software development projects using Agile methodologies. Based in Mumbai.',
      applyUrl: '#',
      location: 'Mumbai',
      isRemote: false,
      experienceLevel: 'Senior Level',
    },
     {
      jobTitle: 'AI/ML Engineer (Sample)',
      companyName: 'Sample AI Corp',
      shortDescription: 'Work on cutting-edge machine learning models. Experience with TensorFlow/PyTorch preferred. Chennai.',
      applyUrl: '#',
      location: 'Chennai',
       isRemote: false,
       experienceLevel: 'Mid Level',
    },
     {
      jobTitle: 'Full Stack Developer (Node/React) (Sample)',
      companyName: 'Sample FullStack Co.',
      shortDescription: 'Develop and maintain both frontend and backend systems. Opportunity in Delhi.',
      applyUrl: '#',
      location: 'Delhi',
       isRemote: false,
       experienceLevel: 'Entry Level',
    },
];

/**
 * Recommends job listings based on input criteria.
 * Currently, this function *always* returns the first 3 mock job listings
 * for India, regardless of the input provided. This is for stable demo purposes.
 *
 * @param input The input criteria including course, skills, and filters (ignored).
 * @returns A promise that resolves to an array of exactly 3 JobListing objects.
 */
export async function recommendJobs(input: RecommendJobsInput): Promise<RecommendJobsOutput> {
   console.log("recommendJobs called with (input ignored):", input);
   console.warn("NOTE: Returning first 3 hardcoded mock job data. Input filters are not applied.");

   // Directly take the first 3 jobs from the mock data
   const jobsToReturn = MOCK_INDIA_JOBS.slice(0, 3);

   // Simulate network delay
   await new Promise(resolve => setTimeout(resolve, 200)); // Shorter delay for mock data

   // Validate output against schema before returning (good practice)
   const validation = RecommendJobsOutputSchema.safeParse(jobsToReturn);
   if (!validation.success) {
       console.error("Mock data slicing resulted in invalid output:", validation.error);
       // As a fallback, return the original first 3 again if validation somehow fails
       return MOCK_INDIA_JOBS.slice(0, 3);
   }

   // Return the first 3 mock jobs
   return validation.data;
}

// ---- AI Flow Implementation Removed ----
// The Genkit flow, prompt, and tool definitions are removed as the
// `recommendJobs` function now directly returns mock data.
// Keeping the dependency on Genkit/AI out simplifies this feature
// and avoids API key issues in the demo environment.
// import {ai} from '@/ai/ai-instance'; // No longer needed
// const getJobListingsTool = ... // Removed
// const prompt = ... // Removed
// const recommendJobsFlow = ... // Removed

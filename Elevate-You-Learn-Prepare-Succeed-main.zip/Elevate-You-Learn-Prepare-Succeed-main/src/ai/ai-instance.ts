import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/googleai';

export const ai = genkit({
  promptDir: './prompts',
  plugins: [
    googleAI({
      // Ensure GOOGLE_GENAI_API_KEY is set in your environment variables
      apiKey: process.env.GOOGLE_GENAI_API_KEY || process.env.GOOGLE_API_KEY,
    }),
  ],
  // Specify the model to use
  // model: 'googleai/gemini-1.5-flash', // Or another suitable model
});

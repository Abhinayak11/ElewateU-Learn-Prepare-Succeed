
// This file can be used to register flows for local development/testing
// with the Genkit CLI using `genkit start`.
// Example: import './flows/some-flow.js';

// Explicitly import flows to ensure they are registered for local dev/testing
import '@/ai/flows/job-recommendation.ts';
import '@/ai/flows/mock-interview-chatbot.ts';

import * as React from "react"

// Standard mobile breakpoint (Tailwind's `md`)
const MOBILE_BREAKPOINT = 768

/**
 * Custom hook to detect if the current viewport width is considered mobile.
 * Returns `true` if width < MOBILE_BREAKPOINT, `false` otherwise.
 * Initial state is `undefined` until client-side hydration.
 */
export function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = React.useState<boolean>(() => {
     // Check initial value only on client-side
     if (typeof window === "undefined") {
         return false; // Default to false during SSR
     }
     return window.innerWidth < MOBILE_BREAKPOINT;
  });

  React.useEffect(() => {
     // Ensure this effect runs only on the client
     if (typeof window === "undefined") {
         return;
     }

    const checkSize = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }

    // Initial check in case the state didn't match during hydration
    checkSize();

    window.addEventListener("resize", checkSize)
    return () => window.removeEventListener("resize", checkSize) // Cleanup listener
  }, []) // Empty dependency array ensures this runs once on mount

  return isMobile;
}

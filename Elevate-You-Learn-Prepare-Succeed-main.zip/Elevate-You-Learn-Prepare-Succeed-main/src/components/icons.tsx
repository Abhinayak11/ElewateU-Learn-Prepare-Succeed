import { Menu, LayoutDashboard } from "lucide-react";

export const MenuIcon = Menu;
export const LogoIcon = LayoutDashboard;
export const Icons = {
    menu: Menu,
    logo: LayoutDashboard,
};
import React from "react"
import Link from "next/link"

import { cn } from "@/lib/utils"
import { Icons } from "@/components/icons"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"

interface MainNavProps extends React.HTMLAttributes<HTMLElement> {
  items?: {
    title: string
    href: string
    description?: string
    items?: { title: string; href: string }[]
  }[]
}

export function MainNav({ className, items, ...props }: MainNavProps) {
  return (
    <nav className={cn("flex items-center space-x-6 lg:space-x-8", className)} {...props}>
      <Link href="/" className="flex items-center space-x-2">
        <Icons.logo className="h-6 w-6" />
        <span className="hidden font-bold sm:inline-block">CareerFlow</span>
      </Link>
      {items?.length ? (
        <NavigationMenu>
          <NavigationMenuList>
            {items?.map((item) => (
              <NavigationMenuItem key={item.title}>
                {!item.items && (
                  <Link href={item.href} legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      {item.title}
                    </NavigationMenuLink>
                  </Link>
                )}
                {item.items && (
                  <>
                    <NavigationMenuTrigger>{item.title}</NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                        {item.items.map((item) => (
                          <li key={item.href} className="row-span-1">
                            <Link
                              href={item.href}
                              className="block h-full w-full select-none space-y-1 rounded-md bg-muted/50 p-4 text-sm leading-tight no-underline outline-none focus:shadow-md"
                              legacyBehavior
                            >
                              <NavigationMenuLink>{item.title}</NavigationMenuLink>
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </NavigationMenuContent>
                  </>
                )}
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>
      ) : null}
    </nav>
  )
}
"use client"

import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"
import { useToast } from "@/hooks/use-toast"

export function Toaster() {
  const { toasts } = useToast() // Use the custom hook to get toasts

  return (
    <ToastProvider>
      {toasts.map(function ({ id, title, description, action, ...props }) {
        return (
          <Toast key={id} {...props}> {/* Render each toast */}
            <div className="grid gap-1"> {/* Grid for title/description */}
              {title && <ToastTitle>{title}</ToastTitle>}
              {description && (
                <ToastDescription>{description}</ToastDescription>
              )}
            </div>
            {action} {/* Render action button if provided */}
            <ToastClose /> {/* Add close button */}
          </Toast>
        )
      })}
      <ToastViewport /> {/* Viewport where toasts appear */}
    </ToastProvider>
  )
}

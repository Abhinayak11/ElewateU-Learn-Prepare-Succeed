"use client"

// Credits: https://ui.shadcn.com/docs/components/form

import * as React from "react"
import * as LabelPrimitive from "@radix-ui/react-label"
import { Slot } from "@radix-ui/react-slot"
import {
  Controller,
  FormProvider,
  useFormContext,
  type ControllerProps,
  type FieldPath,
  type FieldValues,
} from "react-hook-form"

import { cn } from "@/lib/utils"
import { Label } from "@/components/ui/label"

const Form = FormProvider

type FormFieldContextValue<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
> = {
  name: TName
}

// Context to share field name
const FormFieldContext = React.createContext<FormFieldContextValue>(
  {} as FormFieldContextValue
)

// FormField component using Controller from react-hook-form
const FormField = <
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  ...props
}: ControllerProps<TFieldValues, TName>) => {
  return (
    <FormFieldContext.Provider value={{ name: props.name }}>
      <Controller {...props} />
    </FormFieldContext.Provider>
  )
}

// Hook to access field context and state
const useFormField = () => {
  const fieldContext = React.useContext(FormFieldContext)
  const itemContext = React.useContext(FormItemContext)
  const { getFieldState, formState } = useFormContext() // Get form context

  const fieldState = getFieldState(fieldContext.name, formState) // Get state for the specific field

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>")
  }

  // Generate IDs for accessibility
  const { id } = itemContext

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState, // Spread field state (e.g., error, isDirty, isTouched)
  }
}

type FormItemContextValue = {
  id: string
}

// Context to share unique ID within a form item
const FormItemContext = React.createContext<FormItemContextValue>(
  {} as FormItemContextValue
)

// Wrapper component for a single form item (label, input, description, message)
const FormItem = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  const id = React.useId() // Generate a unique ID for the item

  return (
    <FormItemContext.Provider value={{ id }}>
      {/* Default spacing between elements */}
      <div ref={ref} className={cn("space-y-2", className)} {...props} />
    </FormItemContext.Provider>
  )
})
FormItem.displayName = "FormItem"

// Form label component
const FormLabel = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>
>(({ className, ...props }, ref) => {
  const { error, formItemId } = useFormField() // Get error state and ID

  return (
    <Label
      ref={ref}
      // Apply destructive color if there's an error
      className={cn(error && "text-destructive", className)}
      htmlFor={formItemId} // Link label to input
      {...props}
    />
  )
})
FormLabel.displayName = "FormLabel"

// Form control wrapper (usually wraps the input element)
const FormControl = React.forwardRef<
  React.ElementRef<typeof Slot>,
  React.ComponentPropsWithoutRef<typeof Slot>
>(({ ...props }, ref) => {
  const { error, formItemId, formDescriptionId, formMessageId } = useFormField()

  return (
    <Slot
      ref={ref}
      id={formItemId} // Set ID for the input
      // Link input to description and error messages for accessibility
      aria-describedby={
        !error
          ? `${formDescriptionId}`
          : `${formDescriptionId} ${formMessageId}`
      }
      aria-invalid={!!error} // Indicate invalid state if error exists
      {...props}
    />
  )
})
FormControl.displayName = "FormControl"

// Form description component (helper text)
const FormDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => {
  const { formDescriptionId } = useFormField() // Get ID for description

  return (
    <p
      ref={ref}
      id={formDescriptionId} // Set ID for accessibility linkage
      className={cn("text-[0.8rem] text-muted-foreground", className)} // Smaller text, muted color
      {...props}
    />
  )
})
FormDescription.displayName = "FormDescription"

// Form message component (displays validation errors)
const FormMessage = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, children, ...props }, ref) => {
  const { error, formMessageId } = useFormField() // Get error object and ID
  const body = error ? String(error?.message) : children // Display error message or children

  if (!body) {
    return null // Don't render if no message
  }

  return (
    <p
      ref={ref}
      id={formMessageId} // Set ID for accessibility linkage
      className={cn("text-[0.8rem] font-medium text-destructive", className)} // Smaller text, destructive color
      {...props}
    >
      {body}
    </p>
  )
})
FormMessage.displayName = "FormMessage"

export {
  useFormField,
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
}

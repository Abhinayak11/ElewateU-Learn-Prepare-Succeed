"use client"

import * as React from "react"
import * as RechartsPrimitive from "recharts"

import { cn } from "@/lib/utils"

// Format: { THEME_NAME: CSS_SELECTOR }
const THEMES = { light: ":root", dark: ".dark" } as const // Use :root for light theme default

export type ChartConfig = {
  [k in string]: {
    label?: React.ReactNode
    icon?: React.ComponentType
  } & (
    | { color?: string; theme?: never } // Single color definition
    | { color?: never; theme: Record<keyof typeof THEMES, string> } // Theme-specific colors
  )
}

type ChartContextProps = {
  config: ChartConfig
}

const ChartContext = React.createContext<ChartContextProps | null>(null)

function useChart() {
  const context = React.useContext(ChartContext)

  if (!context) {
    throw new Error("useChart must be used within a <ChartContainer />")
  }

  return context
}

const ChartContainer = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    config: ChartConfig
    children: React.ComponentProps<
      typeof RechartsPrimitive.ResponsiveContainer
    >["children"]
  }
>(({ id, className, children, config, ...props }, ref) => {
  const uniqueId = React.useId()
  const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`

  return (
    <ChartContext.Provider value={{ config }}>
      <div
        data-chart={chartId}
        ref={ref}
        className={cn(
          "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none",
          // Use CSS variables defined in ChartStyle
           "[&_.recharts-bar_rect]:fill-[var(--color-fg)]",
           "[&_.recharts-line_dot]:fill-[var(--color-fg)]",
           "[&_.recharts-line_curve]:stroke-[var(--color-fg)]",
           "[&_.recharts-area_dot]:fill-[var(--color-fg)]",
           "[&_.recharts-area_area]:fill-[var(--color-fill)]",
           "[&_.recharts-area_curve]:stroke-[var(--color-fg)]",
           "[&_.recharts-pie_sector]:fill-[var(--color-fill)]",
           "[&_.recharts-pie_sector]:stroke-[var(--color-fg)]",
           "[&_.recharts-radial-bar_sector]:fill-[var(--color-fill)]",
           "[&_.recharts-tooltip-cursor]:stroke-[var(--color-fg)]",
          className
        )}
        {...props}
      >
        <ChartStyle id={chartId} config={config} />
        <RechartsPrimitive.ResponsiveContainer>
          {children}
        </RechartsPrimitive.ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  )
})
ChartContainer.displayName = "Chart"

const ChartStyle = ({ id, config }: { id: string; config: ChartConfig }) => {
  const colorConfig = Object.entries(config).filter(
    ([, config]) => config.theme || config.color
  )

  if (!colorConfig.length) {
    return null
  }

  return (
    <style
      dangerouslySetInnerHTML={{
        __html: Object.entries(THEMES)
          .map(
            ([theme, prefix]) => `${prefix} [data-chart=${id}] {
${colorConfig
  .map(([key, itemConfig]) => {
    const color =
      itemConfig.theme?.[theme as keyof typeof itemConfig.theme] ||
      itemConfig.color;
    // Define both fill and stroke CSS variables
    return color
      ? `  --color-${key}: ${color};\n  --fill-${key}: ${color};` // Use same color for fill and stroke by default
      : null;
  })
  .filter(Boolean) // Remove null entries
  .join("\n")}
}
`
          )
          .join("\n"),
      }}
    />
  )
}


const ChartTooltip = RechartsPrimitive.Tooltip

// Improved Tooltip Content with better styling and structure
const ChartTooltipContent = React.forwardRef<
  HTMLDivElement,
  Omit<React.ComponentProps<typeof RechartsPrimitive.Tooltip>, "content"> &
    React.ComponentProps<"div"> & {
      hideLabel?: boolean
      hideIndicator?: boolean
      indicator?: "line" | "dot" | "dashed"
      nameKey?: string
      labelKey?: string
      labelFormatter?: (label: string, payload: any[]) => React.ReactNode; // Use React.ReactNode
       formatter?: (value: number, name: string, item: any, index: number, payload: any[]) => React.ReactNode; // Use React.ReactNode
    }
>(
  (
    {
      active,
      payload,
      className,
      indicator = "dot",
      hideLabel = false,
      hideIndicator = false,
      label,
      labelFormatter,
      labelClassName,
      formatter,
      color, // This prop might be less useful now with CSS variables
      nameKey,
      labelKey,
    },
    ref
  ) => {
    const { config } = useChart()

    const tooltipLabel = React.useMemo(() => {
      if (hideLabel || !payload?.length) {
        return null
      }

      const [item] = payload
      const key = `${labelKey || item?.dataKey || item?.name || "value"}`
      const itemConfig = getPayloadConfigFromPayload(config, item, key)
      const value =
        !labelKey && typeof label === "string"
          ? config[label as keyof typeof config]?.label ?? label // Use ?? instead of ||
          : itemConfig?.label

      if (labelFormatter && value) { // Check if value exists before formatting
        return (
          <div className={cn("font-medium", labelClassName)}>
            {labelFormatter(value as string, payload)} {/* Format the resolved value */}
          </div>
        )
      }

      if (!value) {
        return null
      }

      return <div className={cn("font-medium", labelClassName)}>{value}</div>
    }, [
      label,
      labelFormatter,
      payload,
      hideLabel,
      labelClassName,
      config,
      labelKey,
    ])

    if (!active || !payload?.length) {
      return null
    }

    const nestLabel = payload.length === 1 && indicator !== "dot"

    return (
      <div
        ref={ref}
        className={cn(
          "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background p-2.5 text-xs shadow-xl", // Use background color
          className
        )}
      >
        {!nestLabel ? tooltipLabel : null}
        <div className="grid gap-1.5">
          {payload.map((item, index) => {
            const key = `${nameKey || item.name || item.dataKey || "value"}`
            const itemConfig = getPayloadConfigFromPayload(config, item, key)
            const indicatorColor = itemConfig?.color || item.color // Use resolved item color

            return (
              <div
                key={item.dataKey || index} // Use index as fallback key
                className={cn(
                  "flex w-full items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground",
                  indicator === "dot" && "items-center"
                )}
                // Use CSS variable for color
                 style={{ '--color-fg': `var(--color-${key})`, '--color-fill': `var(--fill-${key})` } as React.CSSProperties}
              >
                 {/* Apply formatter if provided */}
                 {formatter && item?.value !== undefined && item.name ? (
                   formatter(item.value, item.name, item, index, payload)
                 ) : (
                  <>
                    {/* Indicator Icon/Shape */}
                    {itemConfig?.icon ? (
                      <itemConfig.icon />
                    ) : (
                      !hideIndicator && (
                        <div
                          className={cn(
                            "shrink-0 rounded-[2px] border-[1px] border-[var(--color-fg)] bg-[var(--color-fill)]", // Use CSS variables
                            {
                              "h-2.5 w-2.5": indicator === "dot",
                              "w-1 h-full": indicator === "line", // Ensure line takes full height
                              "w-0 border-[1.5px] border-dashed border-[var(--color-fg)] bg-transparent":
                                indicator === "dashed",
                              "my-0.5": nestLabel && indicator === "dashed",
                            }
                          )}
                        />
                      )
                    )}
                     {/* Label and Value */}
                    <div
                      className={cn(
                        "flex flex-1 justify-between leading-none",
                        nestLabel ? "items-end" : "items-center" // Align items based on nesting
                      )}
                    >
                      <div className="grid gap-1.5">
                        {nestLabel ? tooltipLabel : null}
                        <span className="text-muted-foreground">
                          {itemConfig?.label || item.name}
                        </span>
                      </div>
                      {item.value !== undefined && ( // Check for undefined value
                        <span className="font-mono font-medium tabular-nums text-foreground">
                          {/* Ensure value is treated as number for localeString */}
                          {typeof item.value === 'number' ? item.value.toLocaleString() : item.value}
                        </span>
                      )}
                    </div>
                  </>
                )}
              </div>
            )
          })}
        </div>
      </div>
    )
  }
)
ChartTooltipContent.displayName = "ChartTooltipContent"


const ChartLegend = RechartsPrimitive.Legend

// Improved Legend Content
const ChartLegendContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> &
    Pick<RechartsPrimitive.LegendProps, "payload" | "verticalAlign"> & {
      hideIcon?: boolean
      nameKey?: string
    }
>(
  (
    { className, hideIcon = false, payload, verticalAlign = "bottom", nameKey },
    ref
  ) => {
    const { config } = useChart()

    if (!payload?.length) {
      return null
    }

    return (
      <div
        ref={ref}
        className={cn(
          "flex items-center justify-center gap-4 text-xs", // Reduced text size
          verticalAlign === "top" ? "pb-3" : "pt-3", // Consistent padding
          className
        )}
      >
        {payload.map((item) => {
           // Handle potential undefined dataKey safely
          const key = `${nameKey || item.dataKey?.toString() || item.value || "value"}`;
          const itemConfig = getPayloadConfigFromPayload(config, item, key)
          const color = itemConfig?.color || item.color; // Use resolved color

          return (
            <div
              key={item.value?.toString() || key} // Ensure key is string
              className={cn(
                "flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground"
              )}
               style={{ '--color-fg': `var(--color-${key})`, '--color-fill': `var(--fill-${key})` } as React.CSSProperties} // Apply CSS vars
            >
              {itemConfig?.icon && !hideIcon ? (
                <itemConfig.icon />
              ) : (
                <div
                  className="h-2.5 w-2.5 shrink-0 rounded-[3px]" // Slightly larger, rounded square
                  style={{
                    backgroundColor: color, // Use the resolved color directly here for legend icon
                  }}
                />
              )}
               <span className="text-muted-foreground">{itemConfig?.label || item.value}</span> {/* Display label or value */}
            </div>
          )
        })}
      </div>
    )
  }
)
ChartLegendContent.displayName = "ChartLegend"

// Helper to extract item config from a payload. Accounts for nested payload.
function getPayloadConfigFromPayload(
  config: ChartConfig,
  payload: unknown,
  key: string
): ChartConfig[string] | undefined { // Return type clarified
  if (typeof payload !== "object" || payload === null) {
    return undefined
  }

  // Determine the key to use for configuration lookup
  let configKey: string = key;

  // Check if the key exists directly in the payload object and is a string
  if (key in payload && typeof (payload as any)[key] === "string") {
    configKey = (payload as any)[key];
  } else if (
    // Check if payload has a nested 'payload' object
    'payload' in payload &&
    typeof payload.payload === 'object' &&
    payload.payload !== null
  ) {
    const nestedPayload = payload.payload;
    // Check if the key exists in the nested payload and is a string
    if (key in nestedPayload && typeof (nestedPayload as any)[key] === 'string') {
      configKey = (nestedPayload as any)[key];
    }
  }

  // Look up the configuration using the determined key
  // Fallback to the original key if configKey doesn't yield a result
  return config[configKey] ?? config[key];
}


export {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartStyle,
}

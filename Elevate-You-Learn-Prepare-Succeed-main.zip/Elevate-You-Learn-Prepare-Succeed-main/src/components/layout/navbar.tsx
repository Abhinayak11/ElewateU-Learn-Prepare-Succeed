import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { BrainCircuit, Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import * as React from 'react';
import NavbarAuthActions from './navbar-auth-actions';

export default function Navbar() {
  // Placeholder for authentication state - replace with actual logic (e.g., from context or session)
  const isLoggedIn = true;
  const userName = "Demo User";
  const userEmail = "demo@example.com"; // Placeholder email
  const userAvatarUrl = `https://picsum.photos/seed/${userEmail}/40/40`; // Use email for seed

  const navItems = [
      { href: "/courses", label: "Courses" },
      { href: "/resume-builder", label: "Resume Builder" },
      { href: "/job-recommendations", label: "Jobs" },
      { href: "/mock-interviews", label: "Interviews" },
      { href: "/blog", label: "Blog" },
      { href: "/community", label: "Community" },
      // Removed Success Stories link
  ];

    <header className="bg-card shadow-sm sticky top-0 z-50 border-b border-border/60">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors" aria-label="Elevate You Home">
          <BrainCircuit className="h-7 w-7" />
          <span className="text-xl font-semibold">Elevate You</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-1">
           {navItems.map(item => (
                <NavLink key={item.href} href={item.href}>{item.label}</NavLink>
            ))}
        </div>

        {/* Auth Actions & Mobile Menu Trigger */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {isLoggedIn ? (
            <NavbarAuthActions userAvatarUrl={userAvatarUrl} userName={userName} userEmail={userEmail} />

          ) : (
            <div className="hidden md:flex space-x-2">
                <Button variant="outline" size="sm" asChild><Link href="/login">Log In</Link></Button>
                <Button size="sm" asChild><Link href="/signup">Sign Up</Link></Button>
            </div>
          )}

          {/* Mobile Menu Button */}
           <div className="md:hidden">
                 <Sheet>
                     <SheetTrigger asChild>
                         <Button variant="ghost" size="icon" aria-label="Open menu">
                             <Menu className="h-6 w-6" />
                         </Button>
                     </SheetTrigger>
                     <SheetContent side="right" className="w-[280px] sm:w-[320px]">
                         <div className="flex flex-col h-full">
                              {/* Mobile Menu Header */}
                              <div className="p-4 border-b">
                                 <Link href="/" className="flex items-center space-x-2 text-primary mb-4">
                                     <BrainCircuit className="h-6 w-6" />
                                     <span className="text-lg font-semibold">Elevate You</span>
                                 </Link>
                              </div>
                             {/* Mobile Navigation Links */}
                             <nav className="flex-grow flex flex-col py-4 space-y-2 px-4">
                                 {navItems.map(item => (
                                     <SheetClose key={item.href} asChild>
                                         <Link href={item.href} className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                                             {item.label}
                                         </Link>
                                     </SheetClose>
                                 ))}
                             </nav>
                             {/* Mobile Auth Buttons */}
                             {!isLoggedIn && (
                                <div className="p-4 border-t space-y-2">
                                     <SheetClose asChild>
                                         <Button variant="outline" className="w-full" asChild><Link href="/login">Log In</Link></Button>
                                     </SheetClose>
                                     <SheetClose asChild>
                                        <Button className="w-full" asChild><Link href="/signup">Sign Up</Link></Button>
                                     </SheetClose>
                                 </div>
                             )}
                         </div>
                     </SheetContent>
                 </Sheet>
           </div>
        </div>
      </nav>
    </header>
}


// Reusable NavLink component (consider adding active state highlighting)
interface NavLinkProps {
  href: string;
  children: React.ReactNode;
}

function NavLink({ href, children }: NavLinkProps) {
  // TODO: Implement active state based on current pathname
  // const pathname = usePathname(); // Requires 'use client' at the top or in parent
  // const isActive = pathname === href;

  return (
     <Button variant="ghost" asChild className="text-sm font-medium text-foreground hover:text-primary hover:bg-accent/10 transition-colors px-3 py-2 data-[active=true]:text-primary data-[active=true]:bg-accent/10">
        <Link href={href} /* data-active={isActive} */>
            {children}
        </Link>
      </Button>
  );
}

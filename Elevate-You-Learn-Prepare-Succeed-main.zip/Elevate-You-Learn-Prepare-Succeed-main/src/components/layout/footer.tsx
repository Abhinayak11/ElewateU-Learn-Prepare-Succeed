import Link from 'next/link';
import { Github, Linkedin, Twitter, BrainCircuit } from 'lucide-react'; // Added Twitter
import { Separator } from '@/components/ui/separator';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card text-card-foreground mt-16 border-t border-border/60"> {/* Slightly lighter border */}
       <div className="container mx-auto px-4 py-8">
         <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-sm">
             {/* Logo & Description */}
             <div className="space-y-3">
                 <Link href="/" className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors">
                     <BrainCircuit className="h-7 w-7" />
                     <span className="text-xl font-semibold">Elevate You</span>
                 </Link>
                 <p className="text-muted-foreground text-xs">
                    Learn the skills. Build the resume. Land the job. Your partner in tech career growth.
                 </p>
             </div>

             {/* Quick Links */}
             <div className="space-y-2">
                 <h4 className="font-semibold text-foreground mb-2">Quick Links</h4>
                 <FooterLink href="/courses">Courses</FooterLink>
                 <FooterLink href="/resume-builder">Resume Builder</FooterLink>
                 <FooterLink href="/job-recommendations">Job Recommendations</FooterLink>
                 <FooterLink href="/mock-interviews">Mock Interviews</FooterLink>
             </div>

             {/* Resources */}
             <div className="space-y-2">
                  <h4 className="font-semibold text-foreground mb-2">Resources</h4>
                 <FooterLink href="/blog">Blog</FooterLink>
                 <FooterLink href="/community">Community Forum</FooterLink>
                 <FooterLink href="/about">About Us</FooterLink> {/* Added About Us link */}
                 {/* Add Terms/Privacy links if needed */}
                 {/* <FooterLink href="/terms">Terms of Service</FooterLink> */}
                 {/* <FooterLink href="/privacy">Privacy Policy</FooterLink> */}
             </div>

             {/* Social Links */}
             <div className="space-y-2">
                 <h4 className="font-semibold text-foreground mb-2">Connect With Us</h4>
                 <div className="flex space-x-3">
                     <SocialLink href="#" ariaLabel="Twitter Profile"> <Twitter size={18} /> </SocialLink>
                     <SocialLink href="#" ariaLabel="GitHub Repository"> <Github size={18} /> </SocialLink>
                     <SocialLink href="#" ariaLabel="LinkedIn Page"> <Linkedin size={18} /> </SocialLink>
                 </div>
             </div>
         </div>

        <Separator className="my-6 md:my-8" />

        <div className="text-center text-muted-foreground text-xs">
          © {currentYear} Elevate You. All rights reserved. Built with passion (and code!).
        </div>
      </div>
    </footer>
  );
}

// Helper component for footer links
const FooterLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <Link href={href} className="block text-muted-foreground hover:text-primary hover:underline underline-offset-2 transition-colors">
    {children}
  </Link>
);

// Helper component for social media links
const SocialLink = ({ href, children, ariaLabel }: { href: string; children: React.ReactNode; ariaLabel: string }) => (
   <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={ariaLabel}
        className="text-muted-foreground hover:text-primary transition-colors p-1 rounded-full hover:bg-primary/10" // Added padding and hover bg
    >
     {children}
    </a>
);

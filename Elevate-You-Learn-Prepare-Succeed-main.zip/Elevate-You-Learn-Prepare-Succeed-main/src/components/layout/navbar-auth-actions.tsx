"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { LogOut, Settings } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import React from 'react';

interface AuthActionsProps {
  isLoggedIn: boolean;
  userName: string;
  userEmail: string;
}

export function NavbarAuthActions({ isLoggedIn, userName, userEmail }: AuthActionsProps) {
  const userAvatarUrl = `https://picsum.photos/seed/${userEmail}/40/40`;

  const handleLogout = () => {
    // Add actual logout logic here (e.g., clear session, redirect)
    console.log("Logout clicked (Demo)");
    // Potentially redirect or update auth state
  };

  return (
    <div className="flex items-center space-x-2 md:space-x-4">
      {isLoggedIn ? (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-9 w-9 rounded-full focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
              <Avatar className="h-9 w-9 border">
                <AvatarImage src={userAvatarUrl} alt={userName} />
                <AvatarFallback>{userName?.substring(0, 1).toUpperCase() || 'U'}</AvatarFallback>
              </Avatar>
              <span className="sr-only">User Menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">{userName}</p>
                <p className="text-xs leading-none text-muted-foreground">
                  {userEmail}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild className="cursor-pointer">
              <Link href="/settings">
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive focus:bg-destructive/10 cursor-pointer">
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ) : (
        <div className="hidden md:flex space-x-2">
          <Button variant="outline" size="sm" asChild><Link href="/login">Log In</Link></Button>
          <Button size="sm" asChild><Link href="/signup">Sign Up</Link></Button>
        </div>
      )}
    </div>
  );
}
 "use client";

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { recommendJobs, RecommendJobsInput, JobListing } from '@/ai/flows/job-recommendation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, Briefcase, MapPin, Globe, AlertCircle, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Schema includes course and skills, but location is fixed
const filterSchema = z.object({
  course: z.string().min(1, 'Course is required (select "Any" if unsure)'),
  skills: z.string().min(1, 'Skills are required (comma-separated, e.g., React, Python)'),
  experienceLevel: z.string().optional(),
  remote: z.boolean().optional(),
});

// Type derived from schema
type FilterFormData = z.infer<typeof filterSchema>;

// Available courses and experience levels for dropdowns
const courses = ["Any", "Artificial Intelligence", "Machine Learning", "Full Stack Development", "Data Science", "Cloud Computing", "Cybersecurity"];
const experienceLevels = ["Any", "Entry Level", "Mid Level", "Senior Level", "Lead", "Manager"];


export default function JobRecommendationsPage() {
  const [jobListings, setJobListings] = React.useState<JobListing[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [infoMessage, setInfoMessage] = React.useState<string | null>(null); // For informational messages (e.g., mock data used)
  const [hasSearched, setHasSearched] = React.useState(false); // Track if a search has been performed

  // Initialize form with zod resolver and default values
  const { register, handleSubmit, control, formState: { errors }, setValue, watch } = useForm<FilterFormData>({
    resolver: zodResolver(filterSchema),
    defaultValues: {
      course: 'Any', // Default to 'Any'
      skills: '',
      experienceLevel: 'Any', // Default to 'Any'
      remote: false,
    },
  });

   // Watch form values for dynamic updates
  const remoteValue = watch("remote");
  const selectedCourse = watch("course");
  const selectedExperience = watch("experienceLevel");

  const onSubmit = async (data: FilterFormData) => {
    setIsLoading(true);
    setError(null);
    setInfoMessage(null); // Clear messages on new search
    setJobListings([]); // Clear previous results
    setHasSearched(true); // Mark search initiated

    // Prepare skills array
    const skillsArray = data.skills.split(',').map(skill => skill.trim()).filter(skill => skill);

    // Prepare input for the recommendation flow/service
    // NOTE: This input is now ignored by the recommendJobs function, but we still construct it.
    const input: RecommendJobsInput = {
      course: data.course === 'Any' ? 'Any' : data.course,
      skills: skillsArray.length > 0 ? skillsArray : ['general skills'],
      filter: {
        location: 'India', // Always India
        experienceLevel: data.experienceLevel === 'Any' ? undefined : data.experienceLevel, // Omit if 'Any'
        remote: data.remote,
      },
    };

    console.log('Requesting job recommendations with (input will be ignored by mock):', input);

    try {
      // Call the updated recommendJobs function (which now returns fixed mock data)
      const results = await recommendJobs(input);
       console.log('Received results:', results);

        if (!Array.isArray(results)) {
            console.error("Received non-array result:", results);
            throw new Error("Received unexpected data format from the recommendation service.");
        }

        setJobListings(results);

        // Set info message indicating fixed sample data is shown
        setInfoMessage("Displaying the first 3 sample job listings for India. Your filters were not applied in this demo.");


    } catch (err) {
      console.error("Error fetching job recommendations:", err);
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";

      // Display a comprehensive error message
      setError(`Failed to fetch job recommendations. Reason: ${errorMessage}. Please try again later.`);
      setJobListings([]); // Ensure listings are cleared on error

    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-primary">Job Recommendations</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">Enter your details below to view sample job opportunities in India.</p>
      </div>

      <Card className="shadow-md bg-card">
        <CardHeader>
          <CardTitle>Search Criteria (Location: India)</CardTitle>
          <CardDescription>Enter your course, skills, and preferences. (Note: Filters ignored in demo - showing sample jobs).</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {/* Course Selection */}
               <div>
                 <Label htmlFor="course">Course Background</Label>
                 <Select onValueChange={(value) => setValue('course', value)} value={selectedCourse}>
                    <SelectTrigger id="course" aria-label="Select Course">
                      <SelectValue placeholder="Select a course area" />
                    </SelectTrigger>
                    <SelectContent>
                       {courses.map((course) => (
                         <SelectItem key={course} value={course}>{course}</SelectItem>
                       ))}
                    </SelectContent>
                  </Select>
                  {errors.course && <p className="text-destructive text-xs mt-1">{errors.course?.message}</p>}
              </div>

               {/* Skills Input */}
               <div>
                <Label htmlFor="skills">Skills (comma-separated)</Label>
                <Input id="skills" {...register('skills')} placeholder="e.g., React, Node.js, Python, SQL" aria-required="true" />
                 {errors.skills && <p className="text-destructive text-xs mt-1">{errors.skills?.message}</p>}
              </div>

               {/* Experience Level Selection */}
              <div>
                 <Label htmlFor="experienceLevel">Experience Level</Label>
                 <Select onValueChange={(value) => setValue('experienceLevel', value)} value={selectedExperience}>
                    <SelectTrigger id="experienceLevel" aria-label="Select Experience Level">
                      <SelectValue placeholder="Select experience level" />
                    </SelectTrigger>
                    <SelectContent>
                       {experienceLevels.map((level) => (
                         <SelectItem key={level} value={level}>{level}</SelectItem>
                       ))}
                    </SelectContent>
                  </Select>
                  {/* No error message needed as it's optional */}
              </div>

               {/* Remote Checkbox */}
               <div className="flex items-end pb-1.5"> {/* Align checkbox with bottom of input */}
                 <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remote"
                      checked={remoteValue}
                      onCheckedChange={(checked) => setValue('remote', Boolean(checked))}
                      aria-label="Filter for remote jobs only"
                    />
                    <Label htmlFor="remote" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Remote Only (within India)
                    </Label>
                 </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
                 <Button type="submit" disabled={isLoading} className="w-full md:w-auto bg-primary hover:bg-primary/90">
                   {isLoading ? (
                     <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                   ) : (
                     <Search className="mr-2 h-4 w-4" />
                   )}
                   {isLoading ? 'Searching...' : 'Find Sample Jobs'}
                 </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* --- Results Section --- */}
      <div className="mt-8">
            {/* Loading State */}
            {isLoading && (
                <div className="text-center p-8">
                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
                    <p className="mt-2 text-muted-foreground">Loading sample jobs...</p>
                </div>
            )}

            {/* Display Error Message */}
            {!isLoading && error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error Loading Jobs</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            {/* Display Info Message (e.g., using mock data, no results) */}
            {!isLoading && !error && infoMessage && (
                <Alert variant="default" className="border-blue-500 bg-blue-50 text-blue-800 mb-6 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700">
                  <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  <AlertTitle className="font-semibold">Information</AlertTitle>
                  <AlertDescription>{infoMessage}</AlertDescription>
                </Alert>
            )}

            {/* Initial State Message (Before first search and no loading/error) */}
            {!isLoading && !error && !hasSearched && jobListings.length === 0 && (
                <div className="text-center p-8 text-muted-foreground border rounded-md bg-card">
                     <Search className="mx-auto h-10 w-10 text-muted-foreground mb-4" />
                    <p>Enter your details above to search for job recommendations in India.</p>
                </div>
            )}

             {/* Display Job Listings (Only if not loading, no error, and listings exist) */}
            {!isLoading && !error && jobListings.length > 0 && (
                <div className="space-y-6">
                    <h2 className="text-2xl font-semibold text-primary">Sample Job Listings ({jobListings.length} found)</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {jobListings.map((job, index) => (
                            <Card key={index} className="flex flex-col justify-between shadow-md hover:shadow-lg transition-shadow duration-300 bg-card">
                                <CardHeader>
                                    <CardTitle className="text-lg text-primary group-hover:text-accent transition-colors">{job.jobTitle}</CardTitle>
                                    <CardDescription className="flex items-center text-muted-foreground pt-1">
                                        <Briefcase className="h-4 w-4 mr-1.5" /> {job.companyName}
                                    </CardDescription>
                                    {/* Display location/remote status */}
                                    <CardDescription className="flex items-center text-muted-foreground text-sm pt-1">
                                        {/* Use job data for location/remote status */}
                                        {(job.isRemote) ? (
                                            <> <Globe className="h-4 w-4 mr-1.5" /> Remote ({job.location || 'India'}) </>
                                        ) : (
                                            <> <MapPin className="h-4 w-4 mr-1.5" /> {job.location || 'India'} </> // Default to India if location missing
                                        )}
                                        {/* Display experience level from job data */}
                                        {job.experienceLevel && (
                                            <span className="ml-2 pl-2 border-l border-border"> {job.experienceLevel}</span>
                                        )}
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                    <p className="text-sm">{job.shortDescription}</p>
                                </CardContent>
                                <CardFooter>
                                    <Button asChild size="sm" className="w-full bg-accent text-accent-foreground hover:bg-accent/90" disabled={job.applyUrl === '#'}>
                                        <a href={job.applyUrl === '#' ? undefined : job.applyUrl} target="_blank" rel="noopener noreferrer" className={job.applyUrl === '#' ? 'pointer-events-none opacity-50' : ''}>
                                            {job.applyUrl === '#' ? 'Link Unavailable' : 'Apply Now'}
                                        </a>
                                    </Button>
                                </CardFooter>
                            </Card>
                        ))}
                    </div>
                </div>
            )}
        </div>
    </div>
  );
}

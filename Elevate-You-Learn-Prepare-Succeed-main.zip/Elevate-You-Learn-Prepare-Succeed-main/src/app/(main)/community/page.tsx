"use client";

import * as React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MessageSquare, ThumbsUp, Search, PlusCircle, Loader2 } from 'lucide-react'; // Added Loader2
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea'; // Import Textarea
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Label } from '@/components/ui/label'; // Import Label
import { useToast } from '@/hooks/use-toast'; // Import useToast
import Link from 'next/link'; // Import Link

// Mock Forum Data
const forumThreads = [
  {
    id: 1,
    title: "Struggling with useEffect cleanup function",
    author: "ReactNewbie",
    replies: 15,
    likes: 28,
    lastActivity: "2 hours ago",
    avatarSeed: "reactnewbie-v2", // Updated seed
    category: "React",
  },
  {
    id: 2,
    title: "Best way to structure a large Node.js project?",
    author: "BackendGuru",
    replies: 32,
    likes: 55,
    lastActivity: "5 hours ago",
    avatarSeed: "backend-v2", // Updated seed
    category: "Node.js",
  },
  {
    id: 3,
    title: "Advice needed: Preparing for FAANG interviews",
    author: "AspiringEng",
    replies: 50,
    likes: 102,
    lastActivity: "1 day ago",
    avatarSeed: "faangprep-v2", // Updated seed
    category: "Career Advice",
  },
    {
    id: 4,
    title: "Showcase your latest project!",
    author: "CommunityMod",
    replies: 8,
    likes: 41,
    lastActivity: "3 days ago",
    avatarSeed: "showcase-v2", // Updated seed
    category: "General",
  },
    {
    id: 5,
    title: "Understanding Python decorators",
    author: "PyLearner",
    replies: 22,
    likes: 35,
    lastActivity: "4 days ago",
    avatarSeed: "pythondec-v2", // Updated seed
    category: "Python",
  },
   {
    id: 6,
    title: "How to deploy a Next.js app to Vercel?",
    author: "NextDeployer",
    replies: 12,
    likes: 18,
    lastActivity: "6 hours ago",
    avatarSeed: "verceldeploy-v2", // Updated seed
    category: "Full Stack Development", // Added relevant category
  },
   {
    id: 7,
    title: "Tips for improving Data Visualization skills?",
    author: "DataVizFan",
    replies: 25,
    likes: 60,
    lastActivity: "2 days ago",
    avatarSeed: "dataviztips-v2", // Updated seed
    category: "Data Science", // Added relevant category
  },
];

const categories = ["All", "React", "Node.js", "Career Advice", "Python", "General", "AI/ML", "Full Stack Development", "Data Science"]; // Added new categories

export default function CommunityPage() {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [selectedCategory, setSelectedCategory] = React.useState('All');
    const [newPostTitle, setNewPostTitle] = React.useState('');
    const [newPostBody, setNewPostBody] = React.useState('');
    const [isSubmitting, setIsSubmitting] = React.useState(false); // State for dialog submission
    const [isDialogOpen, setIsDialogOpen] = React.useState(false); // Control dialog open state
    const { toast } = useToast(); // Initialize toast


    const filteredThreads = forumThreads.filter(thread =>
        (selectedCategory === 'All' || thread.category === selectedCategory) &&
        (thread.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
         thread.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
         thread.category.toLowerCase().includes(searchTerm.toLowerCase()) // Search in category too
         )
    );

    const handleCreatePost = (event: React.FormEvent) => {
      event.preventDefault();
      if (!newPostTitle.trim() || !newPostBody.trim()) {
          toast({ title: "Error", description: "Title and body cannot be empty.", variant: "destructive" });
          return;
      }
      setIsSubmitting(true);
      console.log("Submitting new post:", { title: newPostTitle, body: newPostBody });

      // Simulate API call
      setTimeout(() => {
        // In a real app, you'd add the new post to the state or refetch
        console.log(`Demo: Post "${newPostTitle}" created!`);
        toast({
            title: "Post Created!",
            description: `Your post "${newPostTitle}" has been added to the forum (Demo).`,
        });
        setNewPostTitle('');
        setNewPostBody('');
        setIsSubmitting(false);
        setIsDialogOpen(false); // Close the dialog
      }, 1000);
    };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-primary mb-2">Community Forum</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Connect with peers, ask questions, share knowledge, and grow together.
        </p>
      </div>

      {/* Controls: Search, Filter, New Post */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 sticky top-[65px] bg-background py-4 z-40 border-b"> {/* Make controls sticky */}
        <div className="relative flex-grow">
          <Input
            type="search"
            placeholder="Search topics, authors, categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            aria-label="Search forum topics"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" /> {/* Added pointer-events-none */}
        </div>

        <div className="flex items-center gap-2 flex-wrap justify-center md:justify-start">
           <span className="text-sm font-medium text-muted-foreground mr-2 hidden sm:inline">Filter:</span>
           {categories.map(category => (
               <Button
                 key={category}
                 variant={selectedCategory === category ? "default" : "outline"}
                 size="sm"
                 onClick={() => setSelectedCategory(category)}
                 className={`transition-colors duration-200 ${selectedCategory === category ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'hover:bg-accent/10'}`} // Added hover effect
               >
                 {category}
               </Button>
           ))}
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
             <Button className="bg-accent text-accent-foreground hover:bg-accent/90 flex-shrink-0">
               <PlusCircle className="mr-2 h-4 w-4" /> Create New Post
             </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <form onSubmit={handleCreatePost}>
               <DialogHeader>
                 <DialogTitle>Create a New Forum Post</DialogTitle>
                 <DialogDescription>
                   Share your thoughts or questions with the community. Choose an appropriate title and be descriptive.
                 </DialogDescription>
               </DialogHeader>
               <div className="grid gap-4 py-4">
                 <div className="grid grid-cols-4 items-center gap-4">
                   <Label htmlFor="post-title" className="text-right">
                     Title
                   </Label>
                   <Input
                     id="post-title"
                     value={newPostTitle}
                     onChange={(e) => setNewPostTitle(e.target.value)}
                     className="col-span-3"
                     placeholder="Enter post title"
                     required
                     aria-required="true"
                   />
                 </div>
                 <div className="grid grid-cols-4 items-start gap-4">
                   <Label htmlFor="post-body" className="text-right pt-2">
                     Body
                   </Label>
                   <Textarea
                     id="post-body"
                     value={newPostBody}
                     onChange={(e) => setNewPostBody(e.target.value)}
                     className="col-span-3 min-h-[150px]"
                     placeholder="Write your post content here..."
                     required
                     aria-required="true"
                   />
                 </div>
                 {/* TODO: Add category selection dropdown if needed */}
               </div>
               <DialogFooter>
                 <DialogClose asChild>
                    <Button type="button" variant="outline" id="close-dialog-button">Cancel</Button>
                  </DialogClose>
                 <Button type="submit" disabled={isSubmitting || !newPostTitle.trim() || !newPostBody.trim()}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    {isSubmitting ? 'Posting...' : 'Create Post'}
                 </Button>
               </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

      </div>

      {/* Separator removed as sticky header provides visual separation */}

      {/* Forum Threads List */}
      <div className="space-y-4 pt-4"> {/* Add padding top */}
        {filteredThreads.length > 0 ? (
            filteredThreads.map((thread) => (
              <Card key={thread.id} className="hover:shadow-md transition-shadow duration-200 bg-card"> {/* Added bg-card */}
                <CardContent className="p-4 flex flex-col sm:flex-row items-start gap-4">
                  <Avatar className="h-10 w-10 border flex-shrink-0">
                     <AvatarImage src={`https://picsum.photos/seed/${thread.avatarSeed}/40/40`} alt={thread.author} />
                     <AvatarFallback>{thread.author.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-grow">
                    {/* Make title clickable (points to a non-existent detail page for now) */}
                    <Link href={`/community/thread/${thread.id}`} className="text-lg font-semibold text-primary hover:underline mb-1 block">{thread.title}</Link>
                    <p className="text-sm text-muted-foreground">
                      Started by <span className="font-medium text-foreground">{thread.author}</span> • Last activity: {thread.lastActivity} • In <span className="font-medium text-accent">{thread.category}</span>
                    </p>
                  </div>
                  <div className="flex flex-row sm:flex-col items-center sm:items-end text-sm text-muted-foreground space-x-4 sm:space-x-0 sm:space-y-1 flex-shrink-0 ml-0 sm:ml-4 mt-2 sm:mt-0">
                    <div className="flex items-center gap-1.5" title={`${thread.replies} replies`}>
                      <MessageSquare className="h-4 w-4" />
                      <span>{thread.replies}</span>
                       <span className="sr-only">replies</span>
                    </div>
                    <div className="flex items-center gap-1.5" title={`${thread.likes} likes`}>
                      <ThumbsUp className="h-4 w-4" />
                      <span>{thread.likes}</span>
                       <span className="sr-only">likes</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
        ) : (
            <div className="text-center py-16 text-muted-foreground bg-card rounded-lg border"> {/* Enhanced styling */}
                <MessageSquare className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p className="font-semibold text-lg mb-2">No Posts Found</p>
                <p>No forum posts match your current search and filter criteria.</p>
                <p>Try adjusting your search, changing the category filter, or be the first to start a discussion!</p>
            </div>
        )}
      </div>
    </div>
  );
}
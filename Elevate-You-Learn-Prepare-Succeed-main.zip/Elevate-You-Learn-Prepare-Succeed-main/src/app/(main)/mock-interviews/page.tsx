
"use client";

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { INTERVIEW_QUESTIONS_BANK } from '@/lib/interview-questions';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Send, MessageSquare, Timer, Lightbulb, AlertCircle, CheckCircle, Play, RefreshCw } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

// Schema for user response validation
const interviewResponseSchema = z.object({
  userResponse: z.string().min(1, 'Response cannot be empty'),
});

type InterviewResponseFormData = z.infer<typeof interviewResponseSchema>;

// Infer career paths from the keys of the question bank
type CareerPath = keyof typeof INTERVIEW_QUESTIONS_BANK;
const careerPaths = Object.keys(INTERVIEW_QUESTIONS_BANK) as CareerPath[];

interface Message {
  role: 'user' | 'bot';
  content: string;
  isError?: boolean;
}

// Enum for interview status
enum InterviewStatus {
  Idle = 'idle', // No path selected or reset
  Ready = 'ready', // Path selected, ready to start
  Active = 'active', // Interview in progress
  Loading = 'loading', // Starting interview or processing response
  Finished = 'finished', // Interview completed
  Error = 'error', // An error occurred
}

export default function MockInterviewPage() {
    const [interviewStatus, setInterviewStatus] = React.useState<InterviewStatus>(InterviewStatus.Idle);
    const [conversation, setConversation] = React.useState<Message[]>([]);
    const [errorMessage, setErrorMessage] = React.useState<string | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = React.useState<number>(-1); // -1: Not started
    const [currentQuestions, setCurrentQuestions] = React.useState<string[]>([]);
    const [timer, setTimer] = React.useState<number>(0);
    const [isTimerRunning, setIsTimerRunning] = React.useState<boolean>(false);
    const [selectedCareerPath, setSelectedCareerPath] = React.useState<CareerPath | ''>('');
    const [showTips, setShowTips] = React.useState<boolean>(false);

    const { toast } = useToast();
    const timerIntervalRef = React.useRef<NodeJS.Timeout | null>(null);
    const scrollAreaRef = React.useRef<HTMLDivElement>(null);

    const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<InterviewResponseFormData>({
      resolver: zodResolver(interviewResponseSchema),
      defaultValues: { userResponse: '' },
    });
    const userResponseValue = watch('userResponse');

    // --- UI Calculations & Helpers ---
    // Moved calculations up for correct initialization order
    const isLoading = interviewStatus === InterviewStatus.Loading;
    const isInterviewActive = interviewStatus === InterviewStatus.Active;
    const isInputDisabled = !isInterviewActive || isLoading;
    const isSubmitDisabled = isInputDisabled || !userResponseValue?.trim();
    const canSelectPath = interviewStatus === InterviewStatus.Idle || interviewStatus === InterviewStatus.Ready || interviewStatus === InterviewStatus.Finished || interviewStatus === InterviewStatus.Error;
    const canStartInterview = interviewStatus === InterviewStatus.Ready;
    const canReset = interviewStatus !== InterviewStatus.Idle; // Can reset unless already idle

    const totalQuestionCount = currentQuestions.length;
    const validQuestionIndex = currentQuestionIndex >= 0 && currentQuestionIndex < totalQuestionCount;

    const progressValue = totalQuestionCount > 0 && validQuestionIndex
        ? interviewStatus === InterviewStatus.Finished
            ? 100
            : ((currentQuestionIndex + 1) / totalQuestionCount) * 100
        : 0;

    const currentQuestionNumber = (isInterviewActive || (interviewStatus === InterviewStatus.Loading && validQuestionIndex) || interviewStatus === InterviewStatus.Finished) && validQuestionIndex
                                    ? currentQuestionIndex + 1
                                    : 0;


    // --- Effects ---

    // Auto-scroll chat to bottom
    React.useEffect(() => {
      if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
        if (viewport) {
          setTimeout(() => {
             if (viewport) {
                viewport.scrollTop = viewport.scrollHeight;
             }
          }, 100); // Short delay to allow DOM updates
        }
      }
       console.log("[Effect] Conversation updated, scrolling.", conversation);
    }, [conversation]); // Trigger scroll when conversation changes

    // Timer logic
    React.useEffect(() => {
        if (isTimerRunning) {
             console.log("[Effect] Starting timer interval.");
            timerIntervalRef.current = setInterval(() => setTimer((prev) => prev + 1), 1000);
        } else if (timerIntervalRef.current) {
             console.log("[Effect] Clearing timer interval.");
            clearInterval(timerIntervalRef.current);
            timerIntervalRef.current = null;
        }
        return () => {
            if (timerIntervalRef.current) {
                 console.log("[Effect] Cleanup: Clearing timer interval.");
                clearInterval(timerIntervalRef.current);
                timerIntervalRef.current = null;
            }
        };
    }, [isTimerRunning]);

    // --- Timer Controls ---
    const startTimer = () => {
        console.log("[Timer] Starting timer.");
        setTimer(0);
        setIsTimerRunning(true);
    };
    const stopTimer = () => {
        if (isTimerRunning) {
             console.log("[Timer] Stopping timer.");
             setIsTimerRunning(false);
        }
    };
    const formatTime = (timeInSeconds: number) => {
        const minutes = Math.floor(timeInSeconds / 60);
        const seconds = timeInSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    // --- Core Interview Logic ---

    const handleResetInterview = () => {
        console.log(`%c[Action] handleResetInterview triggered.`, 'color: orange; font-weight: bold;');
        stopTimer();
        setTimer(0);
        setConversation([]);
        setErrorMessage(null);
        setCurrentQuestionIndex(-1);
        setCurrentQuestions([]);
        setInterviewStatus(InterviewStatus.Idle);
        reset({ userResponse: '' });
        setShowTips(false);
        setSelectedCareerPath('');
        toast({ title: "Interview Reset", description: "Select a new career path to start again." });
    };

    const handleCareerPathSelect = (careerPath: CareerPath | '') => {
        console.log(`%c[Action] handleCareerPathSelect: Path selected - '${careerPath}'`, 'color: blue; font-weight: bold;');
        if (interviewStatus === InterviewStatus.Active || interviewStatus === InterviewStatus.Loading) {
            toast({ title: "Interview in Progress", description: "Please finish or reset the current interview before changing paths.", variant: "default" });
            return;
        }
        setSelectedCareerPath(careerPath);
        setErrorMessage(null);
        setConversation([]);
        setCurrentQuestionIndex(-1);
        setCurrentQuestions([]);
        setInterviewStatus(careerPath ? InterviewStatus.Ready : InterviewStatus.Idle);
        console.log(`[Action] handleCareerPathSelect: Status set to ${careerPath ? 'Ready' : 'Idle'}`);
    };

    const handleStartInterview = async () => {
      if (interviewStatus !== InterviewStatus.Ready || !selectedCareerPath) {
        console.error(`[StartInterview] Cannot start: Invalid state. Status: ${interviewStatus}, Path: ${selectedCareerPath}`);
        setErrorMessage("Please select a career path first.");
        setInterviewStatus(InterviewStatus.Error);
        return;
      }

      console.log(`%c[StartInterview] Starting for path: ${selectedCareerPath}`, 'color: green; font-weight: bold;');
      setInterviewStatus(InterviewStatus.Loading); // Set loading state
      console.log(`[StartInterview] Status set to Loading.`);
      setErrorMessage(null);
      setConversation([]);
      setCurrentQuestions([]);
      setCurrentQuestionIndex(-1);

      try {
        // Get questions for the selected path
        const questions = INTERVIEW_QUESTIONS_BANK[selectedCareerPath];
        console.log(`[StartInterview] Fetched questions for ${selectedCareerPath}:`, questions);

        if (!Array.isArray(questions) || questions.length === 0) {
          throw new Error(`No interview questions available for ${selectedCareerPath}.`);
        }

        // Use only the first 5 questions
        const activeQuestions = questions.slice(0, 5);
        console.log(`[StartInterview] Using active questions:`, activeQuestions);

        if (activeQuestions.length === 0 || typeof activeQuestions[0] !== 'string' || activeQuestions[0].trim() === '') {
          console.error("[StartInterview] Critical: No valid first question found in active questions.");
          throw new Error(`Valid first question for ${selectedCareerPath} is unavailable.`);
        }

        // Set the questions state FIRST
        setCurrentQuestions(activeQuestions);
        console.log(`[StartInterview] State 'currentQuestions' set.`);

        // Simulate loading period
        await new Promise(resolve => setTimeout(resolve, 300));

        // Prepare initial messages
        const introMessage: Message = { role: 'bot', content: `Okay, let's begin the mock interview for ${selectedCareerPath}. We have ${activeQuestions.length} questions. Here's your first one:` };
        const firstQuestionMessage: Message = { role: 'bot', content: activeQuestions[0] };
        console.log(`[StartInterview] Initial messages prepared:`, [introMessage, firstQuestionMessage]);

        // Update conversation and index state
        setConversation([introMessage, firstQuestionMessage]);
        console.log(`[StartInterview] State 'conversation' set.`);
        setCurrentQuestionIndex(0); // Set index to 0 (first question)
        console.log(`[StartInterview] State 'currentQuestionIndex' set to 0.`);

        // Set status to Active and start timer LAST
        setInterviewStatus(InterviewStatus.Active);
        console.log(`%c[StartInterview] Status set to Active. Interview should start.`, 'color: lightgreen; font-weight: bold;');
        startTimer();

      } catch (err) {
        console.error("[StartInterview] Error during interview start:", err);
        const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
        setErrorMessage(`Failed to start the interview for ${selectedCareerPath}. Reason: ${errorMsg}. Please try again or select a different path.`);
        setConversation([{ role: 'bot', content: `Sorry, I couldn't start the interview for ${selectedCareerPath}. Error: ${errorMsg}`, isError: true }]);
        setInterviewStatus(InterviewStatus.Error);
        setCurrentQuestions([]); // Clear questions on error
        setCurrentQuestionIndex(-1); // Reset index on error
        console.log(`[StartInterview] Status set to Error.`);
      }
    };


    const onSubmit = async (data: InterviewResponseFormData) => {
       const submittedQuestionIndex = currentQuestionIndex;
       console.log(`%c[onSubmit] Attempting submission for Q index ${submittedQuestionIndex}. Status: ${interviewStatus}`, 'color: purple; font-weight: bold;');


        if (!isInterviewActive || submittedQuestionIndex < 0 || submittedQuestionIndex >= currentQuestions.length) {
            console.warn(`[onSubmit] Submission ignored. Invalid state (status: ${interviewStatus}, index: ${submittedQuestionIndex}, total: ${currentQuestions.length})`);
            toast({ title: "Cannot Submit Now", description: "The interview is not active or the question index is invalid.", variant: "default" });
            return;
        }

        console.log(`[onSubmit] Valid submission for Q index ${submittedQuestionIndex}. Stopping timer.`);
        stopTimer();
        setInterviewStatus(InterviewStatus.Loading);
        console.log(`[onSubmit] Status set to Loading.`);
        setErrorMessage(null);

        const userMessage: Message = { role: 'user', content: data.userResponse };
        setConversation(prev => [...prev, userMessage]);
        console.log(`[onSubmit] User message added to conversation.`);
        reset({ userResponse: '' }); // Clear input field

        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 400));

        const nextQuestionIndex = submittedQuestionIndex + 1;
        console.log(`[onSubmit] Calculated next index: ${nextQuestionIndex}. Total questions: ${currentQuestions.length}`);

         try {
             if (nextQuestionIndex < currentQuestions.length) {
                 const nextQuestionText = currentQuestions[nextQuestionIndex];
                  console.log(`[onSubmit] Next question text: "${nextQuestionText}"`);

                 if (typeof nextQuestionText !== 'string' || nextQuestionText.trim() === '') {
                     console.error(`[onSubmit] Invalid question text found at index ${nextQuestionIndex}.`);
                     throw new Error(`Internal Error: Could not display question ${nextQuestionIndex + 1}. Please reset the interview.`);
                 }

                 const nextQuestionMessage: Message = { role: 'bot', content: nextQuestionText };
                 setConversation(prev => [...prev, nextQuestionMessage]);
                 console.log(`[onSubmit] Bot message for next question added to conversation.`);
                 setCurrentQuestionIndex(nextQuestionIndex); // Update index
                 console.log(`[onSubmit] State 'currentQuestionIndex' set to ${nextQuestionIndex}.`);
                 setInterviewStatus(InterviewStatus.Active); // Set back to active
                 console.log(`[onSubmit] Status set to Active. Starting timer.`);
                 startTimer();

             } else {
                  console.log(`[onSubmit] Reached end of questions.`);
                 const endMessage: Message = { role: 'bot', content: `That concludes the mock interview for ${selectedCareerPath}. Well done!` };
                 setConversation(prev => [...prev, endMessage]);
                 console.log(`[onSubmit] End message added to conversation.`);
                 setInterviewStatus(InterviewStatus.Finished);
                 console.log(`[onSubmit] Status set to Finished.`);
                 stopTimer(); // Ensure timer is stopped
                 toast({
                     title: "Interview Complete!",
                     description: `You finished the mock interview for ${selectedCareerPath}.`,
                     variant: "default",
                 });
             }
         } catch (err) {
             console.error("[onSubmit] CRITICAL ERROR processing next step:", err);
             const errorMsg = err instanceof Error ? err.message : "An unknown error occurred during the interview.";
             setErrorMessage(errorMsg);
             setConversation(prev => [...prev, { role: 'bot', content: `Error: ${errorMsg}`, isError: true }]);
             setInterviewStatus(InterviewStatus.Error);
             console.log(`[onSubmit] Status set to Error.`);
             stopTimer();
         }
    };


    const getPlaceholderText = () => {
        switch (interviewStatus) {
            case InterviewStatus.Idle: return "Select a career path to begin.";
            case InterviewStatus.Ready: return "Press 'Start Interview' to begin.";
            case InterviewStatus.Loading: return currentQuestionIndex === -1 ? "Starting interview..." : "Processing response...";
            case InterviewStatus.Active: return `Type your response to question ${currentQuestionNumber} of ${totalQuestionCount}...`;
            case InterviewStatus.Finished: return "Interview finished. Reset to start again.";
            case InterviewStatus.Error: return "An error occurred. Please reset.";
            default: return "Loading state...";
        }
    };

    // Debug log for state changes
    React.useEffect(() => {
        console.log(`[State Update] Status: ${interviewStatus}, Path: ${selectedCareerPath}, Q Index: ${currentQuestionIndex}, Total Qs: ${currentQuestions.length}, Convo Len: ${conversation.length}`);
    }, [interviewStatus, selectedCareerPath, currentQuestionIndex, currentQuestions, conversation]);


    return (
        <div className="space-y-8 flex flex-col lg:flex-row lg:space-x-8 lg:space-y-0">

            {/* Control Panel */}
            <Card className="w-full lg:w-1/3 shadow-md flex-shrink-0 bg-card">
                <CardHeader>
                    <CardTitle>Mock Interview Controls</CardTitle>
                    <CardDescription>Select a path and manage your session.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label htmlFor="careerPath">Career Path</Label>
                        <Select
                            onValueChange={(value: CareerPath | '') => handleCareerPathSelect(value)}
                            value={selectedCareerPath}
                            disabled={!canSelectPath}
                        >
                            <SelectTrigger id="careerPath" aria-label="Select Career Path">
                                <SelectValue placeholder="Choose a career path..." />
                            </SelectTrigger>
                            <SelectContent>
                                {careerPaths.map((path) => (
                                    <SelectItem key={path} value={path}>{path}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        {!canSelectPath && <p className="text-xs text-muted-foreground mt-1">Finish or reset the current interview to change paths.</p>}
                    </div>

                    {canStartInterview && (
                        <Button
                            onClick={handleStartInterview}
                            disabled={isLoading}
                            className="w-full bg-primary hover:bg-primary/90"
                        >
                            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
                            {isLoading ? 'Starting...' : 'Start Interview'}
                        </Button>
                    )}

                    {(isInterviewActive || (interviewStatus === InterviewStatus.Loading && validQuestionIndex) || interviewStatus === InterviewStatus.Finished) && totalQuestionCount > 0 && (
                        <div className="space-y-3 pt-2">
                            <>
                                <div className="flex items-center justify-between text-sm text-muted-foreground">
                                    <span>
                                         Question: {interviewStatus === InterviewStatus.Finished ? totalQuestionCount : Math.min(currentQuestionNumber, totalQuestionCount)} / {totalQuestionCount}
                                    </span>
                                    <div className="flex items-center space-x-1" title="Response Timer">
                                        <Timer className="h-4 w-4" />
                                        <span className="font-medium tabular-nums">{formatTime(timer)}</span>
                                    </div>
                                </div>
                                <Progress value={progressValue} className="h-2" aria-label={`Interview progress ${Math.round(progressValue)}%`} />
                            </>
                        </div>
                    )}

                    {isInterviewActive && (
                        <Button variant="outline" size="sm" onClick={() => setShowTips(!showTips)} className="w-full">
                            <Lightbulb className="mr-2 h-4 w-4" /> {showTips ? 'Hide' : 'Show'} Interview Tips
                        </Button>
                    )}

                    {showTips && isInterviewActive && (
                        <Alert className="mt-4 bg-accent/10 border-accent/30 text-accent-foreground">
                            <Lightbulb className="h-4 w-4 text-accent" />
                            <AlertTitle className="text-accent font-semibold">Interview Tips</AlertTitle>
                            <AlertDescription className="text-xs space-y-1">
                                <p><strong>STAR Method:</strong> Structure answers using Situation, Task, Action, Result.</p>
                                <p><strong>Be Specific:</strong> Use concrete examples and quantify achievements.</p>
                                <p><strong>Listen Carefully:</strong> Ensure you understand the question.</p>
                                <p><strong>Keep it Concise:</strong> Avoid rambling; be direct.</p>
                            </AlertDescription>
                        </Alert>
                    )}

                    {interviewStatus === InterviewStatus.Error && errorMessage && (
                        <Alert variant="destructive" className="mt-4">
                            <AlertCircle className="h-4 w-4" />
                            <AlertTitle>Error</AlertTitle>
                            <AlertDescription>{errorMessage}</AlertDescription>
                        </Alert>
                    )}

                    {interviewStatus === InterviewStatus.Finished && (
                        <Alert variant="default" className="mt-4 border-green-500 bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700">
                            <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                            <AlertTitle className="font-semibold">Interview Complete!</AlertTitle>
                            <AlertDescription>
                                You've completed the mock interview. Review your answers or reset to start again.
                            </AlertDescription>
                        </Alert>
                    )}
                </CardContent>
                <CardFooter>
                    <Button
                        variant="outline"
                        onClick={handleResetInterview}
                        disabled={!canReset}
                        className="w-full"
                    >
                        <RefreshCw className="mr-2 h-4 w-4" /> Reset Interview
                    </Button>
                </CardFooter>
            </Card>

            {/* Chat Interface */}
            <Card className="flex-grow shadow-md flex flex-col bg-card h-[70vh] lg:h-auto">
                <CardHeader>
                    <CardTitle>Interview Chat</CardTitle>
                    <CardDescription>{selectedCareerPath ? `Interviewing for: ${selectedCareerPath}` : 'Select a career path and press Start.'}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col space-y-4 overflow-hidden p-4 md:p-6 h-full">
                    <ScrollArea ref={scrollAreaRef} className="flex-grow border rounded-md p-4 bg-muted/50 mb-4">
                        <div className="space-y-4 pr-2">
                            {conversation.map((msg, index) => (
                                <div key={index} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                                    <div className={`p-3 rounded-lg max-w-[85%] shadow-sm ${
                                        msg.role === 'user'
                                            ? 'bg-primary text-primary-foreground'
                                            : msg.isError
                                            ? 'bg-destructive text-destructive-foreground border border-destructive/50'
                                            : 'bg-background text-foreground border'
                                        }`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                                    </div>
                                </div>
                            ))}
                            {interviewStatus === InterviewStatus.Loading && currentQuestionIndex === -1 && conversation.length === 0 && (
                                <div className="flex justify-center items-center p-4 text-muted-foreground">
                                    <Loader2 className="h-5 w-5 animate-spin mr-2" />
                                    Starting interview...
                                </div>
                            )}
                            {interviewStatus === InterviewStatus.Loading && currentQuestionIndex >= 0 && (
                                <div className="flex justify-center items-center p-4 text-muted-foreground">
                                     <Loader2 className="h-5 w-5 animate-spin mr-2" />
                                     Processing response...
                                </div>
                             )}
                            {interviewStatus === InterviewStatus.Idle && conversation.length === 0 && (
                                <div className="text-center text-muted-foreground p-4">
                                    <MessageSquare className="mx-auto h-8 w-8 mb-2 opacity-50" />
                                    Select a career path from the panel and press 'Start Interview'.
                                </div>
                            )}
                            {interviewStatus === InterviewStatus.Ready && conversation.length === 0 && (
                                <div className="text-center text-muted-foreground p-4">
                                    <Play className="mx-auto h-8 w-8 mb-2 opacity-50" />
                                    Ready to start the interview for {selectedCareerPath}. Press 'Start Interview' in the control panel.
                                </div>
                            )}
                        </div>
                        <ScrollBar orientation="vertical" />
                    </ScrollArea>

                    <form onSubmit={handleSubmit(onSubmit)} className="flex items-start space-x-2 border-t pt-4">
                        <div className="flex-grow">
                            <Label htmlFor="userResponse" className="sr-only">Your Response</Label>
                            <Textarea
                                id="userResponse"
                                {...register('userResponse')}
                                placeholder={getPlaceholderText()}
                                rows={3}
                                className="resize-none disabled:opacity-70"
                                disabled={isInputDisabled}
                                aria-label="Your interview response"
                                aria-invalid={!!errors.userResponse}
                                aria-describedby={errors.userResponse ? "userResponse-error" : undefined}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey && !isSubmitDisabled) {
                                        e.preventDefault();
                                        handleSubmit(onSubmit)();
                                    }
                                }}
                            />
                            {errors.userResponse && <p id="userResponse-error" className="text-destructive text-xs mt-1">{errors.userResponse?.message}</p>}
                        </div>
                        <Button
                            type="submit"
                            disabled={isSubmitDisabled}
                            className="self-end bg-primary hover:bg-primary/90"
                            aria-label="Send response"
                        >
                            {isLoading && isInterviewActive ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                                <Send className="h-4 w-4" />
                            )}
                            <span className="sr-only">Send Response</span>
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

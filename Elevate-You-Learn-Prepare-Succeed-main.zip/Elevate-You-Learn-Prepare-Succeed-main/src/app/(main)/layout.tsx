import Navbar from '@/components/layout/navbar';
import Footer from '@/components/layout/footer';

export default function MainLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      {/* Changed padding for better spacing, especially on smaller screens */}
      <main className="flex-grow container mx-auto px-4 py-6 md:py-10">
          {children}
      </main>
      <Footer />
    </div>
  );
}

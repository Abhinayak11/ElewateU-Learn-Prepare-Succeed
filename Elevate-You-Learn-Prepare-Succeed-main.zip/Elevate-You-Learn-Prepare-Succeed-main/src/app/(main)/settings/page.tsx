"use client";

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { User, Bell, Lock, Palette, Trash2, Loader2 } from 'lucide-react'; // Added Loader2
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'; // Import Avatar components
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog" // Import Alert Dialog

// Mock User Data (replace with actual data fetching/auth context)
const currentUser = {
  name: "Demo User",
  email: "demo@example.com",
  profilePictureUrl: "https://picsum.photos/seed/settingsuser-v2/100/100", // Updated seed
  notifications: {
    emailUpdates: true,
    pushActivity: false,
    communityMentions: true,
  },
  preferences: {
    theme: typeof window !== 'undefined' ? localStorage.getItem('theme') || 'system' : 'system', // Load theme preference
  },
};

// Zod Schemas for Validation
const profileSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  // Add profile picture URL validation if allowing uploads
  profilePictureUrl: z.string().url("Invalid URL").optional().or(z.literal("")),
});

const passwordSchema = z.object({
    currentPassword: z.string().min(1, 'Current password is required'), // Consider min length 8
    newPassword: z.string().min(8, 'New password must be at least 8 characters'),
    confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
    message: "New passwords don't match",
    path: ["confirmPassword"], // path of error
});

const notificationSchema = z.object({
  emailUpdates: z.boolean(),
  pushActivity: z.boolean(),
  communityMentions: z.boolean(),
});

const preferencesSchema = z.object({
  theme: z.enum(["light", "dark", "system"]),
});

type ProfileFormData = z.infer<typeof profileSchema>;
type PasswordFormData = z.infer<typeof passwordSchema>;
type NotificationFormData = z.infer<typeof notificationSchema>;
type PreferencesFormData = z.infer<typeof preferencesSchema>;


export default function SettingsPage() {
    const { toast } = useToast();
    const [isSubmittingProfile, setIsSubmittingProfile] = React.useState(false);
    const [isSubmittingPassword, setIsSubmittingPassword] = React.useState(false);
    const [isSubmittingNotifications, setIsSubmittingNotifications] = React.useState(false);
    const [isSubmittingPreferences, setIsSubmittingPreferences] = React.useState(false);
    const [isDeletingAccount, setIsDeletingAccount] = React.useState(false);

    // Profile Form
    const profileForm = useForm<ProfileFormData>({ // Assign form instance
        resolver: zodResolver(profileSchema),
        defaultValues: {
            name: currentUser.name,
            email: currentUser.email,
            profilePictureUrl: currentUser.profilePictureUrl,
        },
    });

    // Password Form
    const passwordForm = useForm<PasswordFormData>({ // Assign form instance
        resolver: zodResolver(passwordSchema),
         defaultValues: { currentPassword: '', newPassword: '', confirmPassword: '' }
    });

     // Notification Form
    const notifyForm = useForm<NotificationFormData>({ // Assign form instance
        resolver: zodResolver(notificationSchema),
        defaultValues: currentUser.notifications,
    });

     // Preferences Form
    const prefsForm = useForm<PreferencesFormData>({ // Assign form instance
        resolver: zodResolver(preferencesSchema),
        defaultValues: currentUser.preferences,
    });

    // Destructure form methods for easier access
    const { register: registerProfile, handleSubmit: handleProfileSubmit, formState: { errors: profileErrors, isDirty: isProfileDirty }, watch: watchProfile } = profileForm;
    const { register: registerPassword, handleSubmit: handlePasswordSubmit, formState: { errors: passwordErrors, isDirty: isPasswordDirty }, reset: resetPasswordForm } = passwordForm;
    const { register: registerNotify, handleSubmit: handleNotifySubmit, setValue: setNotifyValue, watch: watchNotify, formState: { isDirty: isNotifyDirty } } = notifyForm;
    const { register: registerPrefs, handleSubmit: handlePrefsSubmit, setValue: setPrefsValue, watch: watchPrefs, formState: { isDirty: isPrefsDirty } } = prefsForm;


    // Watch form values
    const emailUpdates = watchNotify("emailUpdates");
    const pushActivity = watchNotify("pushActivity");
    const communityMentions = watchNotify("communityMentions");
    const selectedTheme = watchPrefs("theme");
    const profilePicUrl = watchProfile("profilePictureUrl"); // Watch profile pic URL


    // Apply theme on initial load and when changed
    React.useEffect(() => {
        const applyTheme = (theme: string) => {
             if (typeof window === 'undefined') return; // Guard for SSR
            const root = window.document.documentElement;
            root.classList.remove('light', 'dark');
            if (theme === 'system') {
                const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
                root.classList.add(systemTheme);
            } else {
                root.classList.add(theme);
            }
        };
        applyTheme(selectedTheme);
         if (typeof window !== 'undefined') { // Guard for SSR
             localStorage.setItem('theme', selectedTheme); // Save preference
         }
    }, [selectedTheme]);


    const onProfileSubmit = async (data: ProfileFormData) => {
        setIsSubmittingProfile(true);
        console.log("Updating profile:", data);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setIsSubmittingProfile(false);
        toast({ title: "Profile Updated", description: "Your profile information has been saved." });
         profileForm.reset(data); // Reset dirty state after successful save
    };

    const onPasswordSubmit = async (data: PasswordFormData) => {
        setIsSubmittingPassword(true);
        console.log("Updating password..."); // Don't log password data
        // Simulate API call (check current password, then update)
         await new Promise(resolve => setTimeout(resolve, 1500));
        setIsSubmittingPassword(false);
        // Check result of API call in real app
        toast({ title: "Password Updated", description: "Your password has been changed successfully." });
        resetPasswordForm(); // Clear form after successful submission
    };

     const onNotifySubmit = async (data: NotificationFormData) => {
        setIsSubmittingNotifications(true);
        console.log("Updating notifications:", data);
        // Simulate API call
         await new Promise(resolve => setTimeout(resolve, 700));
         setIsSubmittingNotifications(false);
        toast({ title: "Notifications Updated", description: "Your notification settings have been saved." });
         notifyForm.reset(data); // Reset dirty state
    };

     const onPrefsSubmit = async (data: PreferencesFormData) => {
         setIsSubmittingPreferences(true);
        console.log("Updating preferences:", data);
        // Simulate API call
         await new Promise(resolve => setTimeout(resolve, 500));
         setIsSubmittingPreferences(false);
        toast({ title: "Preferences Updated", description: "Your display preferences have been saved." });
         prefsForm.reset(data); // Reset dirty state
         // Theme is applied via useEffect
    };

    const handleDeleteAccount = async () => {
        setIsDeletingAccount(true);
        console.log("Deleting account...");
        // Simulate API call
         await new Promise(resolve => setTimeout(resolve, 2000));
         setIsDeletingAccount(false);
         toast({
            title: "Account Deletion Processed (Demo)",
            description: "Your account has been successfully deleted.",
            variant: "destructive"
        });
         // Redirect user after deletion (e.g., to home page or logout)
         // window.location.href = '/';
    };


  return (
    <div className="space-y-10 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-primary">Settings</h1>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><User className="h-5 w-5"/> Profile Information</CardTitle>
          <CardDescription>Update your personal details and profile picture.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleProfileSubmit(onProfileSubmit)} className="space-y-6">
             <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={profilePicUrl || `https://picsum.photos/seed/${currentUser.email}-v2/80/80`} alt={currentUser.name} />
                    <AvatarFallback>{currentUser.name?.substring(0, 1).toUpperCase() || 'U'}</AvatarFallback>
                  </Avatar>
                  <div className="flex-grow space-y-2">
                    <Label htmlFor="profilePictureUrl">Profile Picture URL (Optional)</Label>
                    <Input id="profilePictureUrl" {...registerProfile('profilePictureUrl')} placeholder="https://your-image-url.com/pic.jpg" />
                    {profileErrors.profilePictureUrl && <p className="text-destructive text-xs mt-1">{profileErrors.profilePictureUrl.message}</p>}
                    <Button type="button" variant="outline" size="sm" disabled>Upload Image (Demo)</Button> {/* Placeholder for upload */}
                  </div>
             </div>
             <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" {...registerProfile('name')} />
              {profileErrors.name && <p className="text-destructive text-xs mt-1">{profileErrors.name.message}</p>}
            </div>
             <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" {...registerProfile('email')} disabled /> {/* Usually email is not editable or requires verification */}
              <p className="text-xs text-muted-foreground mt-1">Email cannot be changed in this demo.</p>
               {profileErrors.email && <p className="text-destructive text-xs mt-1">{profileErrors.email.message}</p>}
            </div>
            <Button type="submit" disabled={isSubmittingProfile || !isProfileDirty}>
                {isSubmittingProfile && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save Profile Changes
            </Button>
          </form>
        </CardContent>
      </Card>

       <Separator />

      {/* Change Password */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Lock className="h-5 w-5"/> Change Password</CardTitle>
          <CardDescription>Update your account password. Requires current password.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordSubmit(onPasswordSubmit)} className="space-y-4">
            <div>
               <Label htmlFor="currentPassword">Current Password</Label>
               <Input id="currentPassword" type="password" {...registerPassword('currentPassword')} autoComplete="current-password" />
               {passwordErrors.currentPassword && <p className="text-destructive text-xs mt-1">{passwordErrors.currentPassword.message}</p>}
             </div>
             <div>
               <Label htmlFor="newPassword">New Password</Label>
               <Input id="newPassword" type="password" {...registerPassword('newPassword')} autoComplete="new-password" />
                {passwordErrors.newPassword && <p className="text-destructive text-xs mt-1">{passwordErrors.newPassword.message}</p>}
             </div>
             <div>
               <Label htmlFor="confirmPassword">Confirm New Password</Label>
               <Input id="confirmPassword" type="password" {...registerPassword('confirmPassword')} autoComplete="new-password" />
                {passwordErrors.confirmPassword && <p className="text-destructive text-xs mt-1">{passwordErrors.confirmPassword.message}</p>}
             </div>
            <Button type="submit" disabled={isSubmittingPassword || !isPasswordDirty}>
                 {isSubmittingPassword && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update Password
            </Button>
          </form>
        </CardContent>
      </Card>

      <Separator />

       {/* Notification Settings */}
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5"/> Notifications</CardTitle>
           <CardDescription>Manage how you receive notifications from Elevate You.</CardDescription>
         </CardHeader>
         <CardContent>
           <form onSubmit={handleNotifySubmit(onNotifySubmit)} className="space-y-6">
             <div className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
               <Label htmlFor="emailUpdates" className="flex flex-col space-y-1 cursor-pointer flex-grow mr-4">
                 <span>Platform Updates</span>
                 <span className="font-normal leading-snug text-muted-foreground text-sm">
                   Receive occasional emails about new features and important updates.
                 </span>
               </Label>
               <Switch
                 id="emailUpdates"
                 checked={emailUpdates}
                 onCheckedChange={(checked) => setNotifyValue('emailUpdates', checked, { shouldDirty: true })}
                 aria-label="Toggle email updates"
               />
             </div>
              <div className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
               <Label htmlFor="pushActivity" className="flex flex-col space-y-1 cursor-pointer flex-grow mr-4">
                 <span>App Notifications</span>
                  <span className="font-normal leading-snug text-muted-foreground text-sm">
                   Get push notifications for important account activity (Requires Mobile App - Demo).
                 </span>
               </Label>
               <Switch
                 id="pushActivity"
                 checked={pushActivity}
                 onCheckedChange={(checked) => setNotifyValue('pushActivity', checked, { shouldDirty: true })}
                 aria-label="Toggle push notifications"
                 disabled // Assuming no app for now
               />
             </div>
              <div className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
               <Label htmlFor="communityMentions" className="flex flex-col space-y-1 cursor-pointer flex-grow mr-4">
                 <span>Community Mentions</span>
                  <span className="font-normal leading-snug text-muted-foreground text-sm">
                   Notify me when someone mentions me or replies to my post in the forum.
                 </span>
               </Label>
               <Switch
                 id="communityMentions"
                 checked={communityMentions}
                 onCheckedChange={(checked) => setNotifyValue('communityMentions', checked, { shouldDirty: true })}
                 aria-label="Toggle community mention notifications"
               />
             </div>
             <Button type="submit" disabled={isSubmittingNotifications || !isNotifyDirty}>
                 {isSubmittingNotifications && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                 Save Notification Settings
            </Button>
           </form>
         </CardContent>
       </Card>

        <Separator />

       {/* Preferences */}
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2"><Palette className="h-5 w-5"/> Preferences</CardTitle>
           <CardDescription>Customize the look and feel of the application.</CardDescription>
         </CardHeader>
         <CardContent>
            <form onSubmit={handlePrefsSubmit(onPrefsSubmit)} className="space-y-4">
                 <div>
                    <Label htmlFor="theme">Interface Theme</Label>
                     <Select onValueChange={(value: "light" | "dark" | "system") => setPrefsValue('theme', value, { shouldDirty: true })} value={selectedTheme}>
                         <SelectTrigger id="theme" className="w-[180px]">
                             <SelectValue placeholder="Select theme" />
                         </SelectTrigger>
                         <SelectContent>
                             <SelectItem value="light">Light</SelectItem>
                             <SelectItem value="dark">Dark</SelectItem>
                             <SelectItem value="system">System Default</SelectItem>
                         </SelectContent>
                     </Select>
                     <p className="text-sm text-muted-foreground mt-1">Choose how Elevate You looks. 'System' matches your OS setting.</p>
                 </div>
                <Button type="submit" disabled={isSubmittingPreferences || !isPrefsDirty}>
                     {isSubmittingPreferences && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                     Save Preferences
                </Button>
            </form>
         </CardContent>
       </Card>

       <Separator />

      {/* Delete Account */}
       <Card className="border-destructive">
         <CardHeader>
           <CardTitle className="flex items-center gap-2 text-destructive"><Trash2 className="h-5 w-5"/> Danger Zone</CardTitle>
           <CardDescription className="text-destructive/90">Permanently delete your account and all associated data, including saved resumes and progress. This action cannot be undone.</CardDescription>
         </CardHeader>
         <CardContent>
            <AlertDialog>
               <AlertDialogTrigger asChild>
                  <Button variant="destructive" disabled={isDeletingAccount}>
                     {isDeletingAccount && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                     Delete My Account
                  </Button>
               </AlertDialogTrigger>
               <AlertDialogContent>
                 <AlertDialogHeader>
                   <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                   <AlertDialogDescription>
                     This action cannot be undone. This will permanently delete your
                     account and remove all your data from our servers.
                   </AlertDialogDescription>
                 </AlertDialogHeader>
                 <AlertDialogFooter>
                   <AlertDialogCancel disabled={isDeletingAccount}>Cancel</AlertDialogCancel>
                   <AlertDialogAction
                        onClick={handleDeleteAccount}
                        disabled={isDeletingAccount}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                        {isDeletingAccount && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Yes, Delete Account
                   </AlertDialogAction>
                 </AlertDialogFooter>
               </AlertDialogContent>
             </AlertDialog>
         </CardContent>
       </Card>

    </div>
  );
}


// Removed unnecessary helper hook, watch is used directly from the form instance.
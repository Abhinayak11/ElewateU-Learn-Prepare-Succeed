"use client";

import React from 'react';

export default function AboutPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-4xl font-bold text-center mb-8">About Us</h1>

      <div className="max-w-3xl mx-auto">
        <p className="text-gray-700 mb-6">
          Our platform is designed to be a comprehensive hub for career growth and job readiness. We provide a suite of tools and resources aimed at empowering individuals to navigate the job market successfully, from enhancing their skills to securing their dream job.
        </p>
        <p className="text-gray-700 mb-6">
          Our primary goal is to bridge the gap between talent and opportunity. We aim to create a space where job seekers can access personalized career guidance, practice interview skills, get job recommendations and build a compelling resume.
        </p>
        <p className="text-gray-700 mb-6">
          Our vision is to revolutionize the job search and career development experience. We strive to be the go-to platform for anyone looking to advance their career, making the process less daunting and more rewarding.
        </p>
      </div>
    </div>
  );
}

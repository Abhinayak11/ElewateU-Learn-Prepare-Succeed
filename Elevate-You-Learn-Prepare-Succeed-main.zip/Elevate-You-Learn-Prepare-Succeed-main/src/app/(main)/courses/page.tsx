"use client";

import * as React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CheckCircle, Link as LinkIcon, Milestone, BrainCircuit, Code, Monitor, Database, LineChart, Cloud, Shield } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton'; // Import Skeleton

// Helper function to generate Google search links
const createSearchLink = (query: string) => `https://www.google.com/search?q=${encodeURIComponent(query)}`;

// Define Course Categories and Roadmaps
const coursesData = {
  ai: {
    name: "Artificial Intelligence",
    icon: <BrainCircuit className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
      { title: "Fundamentals", description: "Core AI concepts, Python basics.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Introduction to AI", link: createSearchLink("Introduction to Artificial Intelligence concepts"), tooltip: "Understand AI history and applications." },
        { name: "Python for Data Science", link: createSearchLink("Python for Data Science tutorial NumPy Pandas"), tooltip: "Learn essential Python libraries like NumPy and Pandas." },
        { name: "Basic Probability & Statistics", link: createSearchLink("Basic Probability and Statistics for AI"), tooltip: "Grasp statistical concepts crucial for AI." },
      ]},
      { title: "Machine Learning Basics", description: "Supervised and Unsupervised Learning.", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "Linear Regression", link: createSearchLink("Linear Regression tutorial machine learning") },
        { name: "Logistic Regression", link: createSearchLink("Logistic Regression tutorial machine learning") },
        { name: "Clustering (K-Means)", link: createSearchLink("K-Means Clustering tutorial"), tooltip: "Learn about grouping similar data points." },
      ]},
      { title: "Deep Learning", description: "Neural Networks, CNNs, RNNs.", icon: <BrainCircuit className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Introduction to Neural Networks", link: createSearchLink("Introduction to Neural Networks") },
        { name: "Convolutional Neural Networks (CNNs)", link: createSearchLink("Convolutional Neural Networks CNN tutorial"), tooltip: "Key for image recognition." },
        { name: "Recurrent Neural Networks (RNNs)", link: createSearchLink("Recurrent Neural Networks RNN tutorial"), tooltip: "Used for sequential data like text." },
      ]},
      { title: "Specializations", description: "NLP, Computer Vision, etc.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
         { name: "Natural Language Processing (NLP)", link: createSearchLink("Natural Language Processing NLP introduction") },
         { name: "Computer Vision", link: createSearchLink("Computer Vision introduction") },
         { name: "Reinforcement Learning Basics", link: createSearchLink("Reinforcement Learning introduction") },
      ]}
    ]
  },
  ml: {
    name: "Machine Learning",
     icon: <Code className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
       { title: "Python & Data Manipulation", description: "Setup, NumPy, Pandas.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Python Environment Setup", link: createSearchLink("Python environment setup Anaconda venv"), tooltip: "Setting up Anaconda or venv." },
        { name: "NumPy for Numerical Data", link: createSearchLink("NumPy tutorial Python") },
        { name: "Pandas for DataFrames", link: createSearchLink("Pandas DataFrame tutorial Python"), tooltip: "Crucial for data loading and manipulation." },
      ]},
      { title: "Data Preprocessing & EDA", description: "Cleaning, scaling, visualization.", icon: <LineChart className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Data Cleaning Techniques", link: createSearchLink("Data cleaning techniques machine learning") },
        { name: "Feature Scaling", link: createSearchLink("Feature scaling machine learning tutorial") },
        { name: "Handling Missing Values", link: createSearchLink("Handling missing values machine learning"), tooltip: "Essential step before model training." },
        { name: "Exploratory Data Analysis (EDA)", link: createSearchLink("Exploratory Data Analysis tutorial Python") },
      ]},
      { title: "Core ML Algorithms", description: "Supervised & Unsupervised.", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "Linear & Logistic Regression", link: createSearchLink("Linear and Logistic Regression explained") },
        { name: "Support Vector Machines (SVM)", link: createSearchLink("Support Vector Machines SVM tutorial") },
        { name: "Decision Trees & Random Forests", link: createSearchLink("Decision Trees and Random Forests tutorial"), tooltip: "Popular classification and regression methods." },
        { name: "K-Means & Hierarchical Clustering", link: createSearchLink("K-Means Hierarchical Clustering algorithm") },
      ]},
       { title: "Model Evaluation & Selection", description: "Metrics, Cross-Validation.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Classification Metrics (Accuracy, Precision, Recall)", link: createSearchLink("Classification metrics machine learning") },
        { name: "Regression Metrics (MSE, R-squared)", link: createSearchLink("Regression metrics machine learning") },
        { name: "Cross-Validation Techniques", link: createSearchLink("Cross-validation techniques machine learning"), tooltip: "Ensuring model generalizability." },
        { name: "Hyperparameter Tuning", link: createSearchLink("Hyperparameter tuning GridSearch RandomizedSearch") },
      ]},
    ]
  },
  ds: {
    name: "Data Science",
    icon: <Database className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
      { title: "Foundations", description: "Python, SQL, Statistics.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Python Programming (incl. Pandas, NumPy)", link: createSearchLink("Python programming for data science"), tooltip: "Core language and libraries for data manipulation." },
        { name: "SQL for Data Retrieval", link: createSearchLink("SQL tutorial for data analysis"), tooltip: "Essential for querying databases." },
        { name: "Descriptive & Inferential Statistics", link: createSearchLink("Statistics for data science"), tooltip: "Understanding data distributions and hypothesis testing." },
      ]},
      { title: "Data Analysis & Visualization", description: "EDA, Matplotlib, Seaborn.", icon: <LineChart className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Exploratory Data Analysis (EDA)", link: createSearchLink("Exploratory Data Analysis tutorial"), tooltip: "Discovering patterns and anomalies in data." },
        { name: "Data Visualization with Matplotlib", link: createSearchLink("Matplotlib tutorial Python") },
        { name: "Statistical Visualization with Seaborn", link: createSearchLink("Seaborn tutorial Python") },
        { name: "Interactive Plotting (Plotly/Bokeh)", link: createSearchLink("Interactive plotting Plotly Bokeh tutorial"), tooltip: "Creating dynamic visualizations." },
      ]},
      { title: "Machine Learning for Data Science", description: "Core modeling techniques.", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "Introduction to Scikit-learn", link: createSearchLink("Scikit-learn tutorial"), tooltip: "The primary ML library in Python." },
        { name: "Regression Models (Linear, Ridge, Lasso)", link: createSearchLink("Regression models data science") },
        { name: "Classification Models (Logistic, KNN, SVM)", link: createSearchLink("Classification models data science") },
        { name: "Feature Engineering Basics", link: createSearchLink("Feature engineering basics"), tooltip: "Creating effective features for models." },
      ]},
      { title: "Communication & Deployment", description: "Storytelling, Dashboards.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Data Storytelling", link: createSearchLink("Data storytelling techniques"), tooltip: "Communicating insights effectively." },
        { name: "Building Dashboards (Streamlit/Dash)", link: createSearchLink("Streamlit Dash tutorial Python") },
        { name: "Introduction to Model Deployment (e.g., Flask API)", link: createSearchLink("Deploy machine learning model Flask API") },
        { name: "Version Control with Git", link: createSearchLink("Git tutorial for data science") },
      ]},
    ]
  },
  fullstack: {
    name: "Full Stack Development",
     icon: <Monitor className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
       { title: "Frontend Basics", description: "HTML, CSS, JavaScript.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "HTML5 Semantics", link: createSearchLink("HTML5 semantic elements") },
        { name: "CSS Layouts (Flexbox, Grid)", link: createSearchLink("CSS Flexbox Grid tutorial"), tooltip: "Master modern CSS for responsive design." },
        { name: "JavaScript Fundamentals (ES6+)", link: createSearchLink("JavaScript ES6 tutorial") },
        { name: "DOM Manipulation", link: createSearchLink("JavaScript DOM manipulation tutorial") }
      ]},
      { title: "Frontend Framework", description: "React (Recommended).", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "React Fundamentals (Components, Props, State)", link: createSearchLink("React tutorial for beginners") },
        { name: "React Hooks (useState, useEffect)", link: createSearchLink("React Hooks tutorial") },
        { name: "React Router", link: createSearchLink("React Router tutorial") },
        { name: "State Management (Context API / Zustand / Redux)", link: createSearchLink("React state management Context Zustand Redux"), tooltip: "Handle application state effectively." },
      ]},
      { title: "Backend Development", description: "Node.js, Express, Databases.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Node.js & NPM/Yarn", link: createSearchLink("Node.js NPM tutorial") },
        { name: "Building REST APIs with Express", link: createSearchLink("Build REST API Express Node.js") },
        { name: "Database Fundamentals (SQL vs NoSQL)", link: createSearchLink("SQL vs NoSQL databases"), tooltip: "Understand different database paradigms." },
        { name: "Working with Databases (e.g., PostgreSQL/MongoDB)", link: createSearchLink("PostgreSQL MongoDB tutorial Node.js") },
        { name: "Authentication & Authorization (JWT)", link: createSearchLink("Node.js JWT authentication tutorial") },
      ]},
       { title: "Deployment & DevOps Basics", description: "Hosting, Git, CI/CD.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Git & Version Control (GitHub/GitLab)", link: createSearchLink("Git tutorial version control") },
        { name: "Cloud Platforms (Vercel, Netlify, AWS)", link: createSearchLink("Deploy web app Vercel Netlify AWS") },
         { name: "Basic CI/CD with GitHub Actions", link: createSearchLink("CI/CD pipeline tutorial GitHub Actions"), tooltip: "Automate testing and deployment." },
         { name: "Docker Fundamentals", link: createSearchLink("Docker tutorial for beginners") },
      ]},
    ]
  },
   cloud: {
    name: "Cloud Computing",
    icon: <Cloud className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
      { title: "Cloud Concepts", description: "Fundamentals, Service Models.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Introduction to Cloud Computing", link: createSearchLink("Introduction to Cloud Computing") },
        { name: "Service Models (IaaS, PaaS, SaaS)", link: createSearchLink("IaaS PaaS SaaS explained") },
        { name: "Deployment Models (Public, Private, Hybrid)", link: createSearchLink("Public Private Hybrid Cloud explained") },
      ]},
      { title: "Major Cloud Providers", description: "AWS, Azure, GCP Overview.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "AWS Core Services Overview", link: createSearchLink("AWS core services EC2 S3 VPC IAM") },
        { name: "Azure Core Services Overview", link: createSearchLink("Azure core services Virtual Machines Storage Virtual Network Azure AD") },
        { name: "GCP Core Services Overview", link: createSearchLink("GCP core services Compute Engine Cloud Storage VPC Network IAM") },
      ]},
      { title: "Core Services Deep Dive (Choose One)", description: "Compute, Storage, Networking.", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "Virtual Machines (EC2/Azure VM/Compute Engine)", link: createSearchLink("Cloud Virtual Machines tutorial") },
        { name: "Object Storage (S3/Blob Storage/Cloud Storage)", link: createSearchLink("Cloud Object Storage tutorial") },
        { name: "Virtual Networking (VPC/VNet)", link: createSearchLink("Cloud Virtual Networking tutorial") },
        { name: "Identity & Access Management (IAM)", link: createSearchLink("Cloud IAM tutorial") },
      ]},
      { title: "Infrastructure as Code (IaC)", description: "Terraform/CloudFormation.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Introduction to IaC", link: createSearchLink("Infrastructure as Code introduction") },
        { name: "Terraform Basics", link: createSearchLink("Terraform tutorial for beginners") },
        { name: "CloudFormation Basics (if AWS focused)", link: createSearchLink("AWS CloudFormation tutorial") },
      ]},
       { title: "Containers & Serverless", description: "Docker, Kubernetes, Lambda.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Docker Fundamentals", link: createSearchLink("Docker introduction tutorial") },
        { name: "Kubernetes Basics (EKS/AKS/GKE)", link: createSearchLink("Kubernetes tutorial for beginners") },
        { name: "Serverless Concepts (Lambda/Azure Functions/Cloud Functions)", link: createSearchLink("Serverless computing introduction") },
      ]},
    ]
  },
   cybersecurity: {
    name: "Cybersecurity",
    icon: <Shield className="h-5 w-5 mr-2 shrink-0" />,
    roadmap: [
      { title: "Foundations", description: "Networking, OS, Security Principles.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Networking Fundamentals (TCP/IP, OSI Model)", link: createSearchLink("Networking fundamentals TCP/IP OSI model") },
        { name: "Operating Systems Basics (Linux, Windows)", link: createSearchLink("Operating system basics Linux Windows") },
        { name: "Core Security Concepts (CIA Triad)", link: createSearchLink("CIA Triad Cybersecurity") },
        { name: "Introduction to Cryptography", link: createSearchLink("Cryptography basics tutorial") },
      ]},
      { title: "Threats & Vulnerabilities", description: "Malware, Phishing, Attacks.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Common Cyber Threats (Malware, Ransomware, Phishing)", link: createSearchLink("Common cyber threats explained") },
        { name: "Web Application Vulnerabilities (OWASP Top 10)", link: createSearchLink("OWASP Top 10 explained") },
        { name: "Network Vulnerabilities", link: createSearchLink("Common network vulnerabilities") },
      ]},
      { title: "Security Tools & Technologies", description: "Firewalls, IDS/IPS, SIEM.", icon: <CheckCircle className="h-4 w-4 mr-2 text-green-500 shrink-0" />, steps: [
        { name: "Firewalls and Network Security Groups", link: createSearchLink("Firewall Network Security Group tutorial") },
        { name: "Intrusion Detection/Prevention Systems (IDS/IPS)", link: createSearchLink("IDS IPS explained") },
        { name: "Security Information & Event Management (SIEM)", link: createSearchLink("SIEM tutorial for beginners") },
        { name: "Vulnerability Scanning Tools", link: createSearchLink("Vulnerability scanning tools Nessus OpenVAS") },
      ]},
      { title: "Security Operations & Incident Response", description: "Monitoring, Response.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Security Monitoring & Log Analysis", link: createSearchLink("Security monitoring log analysis") },
        { name: "Incident Response Process", link: createSearchLink("Incident response process steps") },
        { name: "Digital Forensics Basics", link: createSearchLink("Digital forensics introduction") },
      ]},
       { title: "Ethical Hacking & Pen Testing (Intro)", description: "Concepts and Phases.", icon: <Milestone className="h-4 w-4 mr-2 shrink-0" />, steps: [
        { name: "Ethical Hacking Concepts", link: createSearchLink("Ethical hacking concepts") },
        { name: "Penetration Testing Phases", link: createSearchLink("Penetration testing phases explained") },
        { name: "Introduction to Kali Linux Tools", link: createSearchLink("Kali Linux tools introduction") },
      ]},
    ]
  },
};

type RoadmapStep = { name: string; link: string; tooltip?: string };
type RoadmapItem = { title: string; description: string; icon: React.ReactNode, steps: RoadmapStep[] };
type CourseCategory = { name: string; icon: React.ReactNode; roadmap: RoadmapItem[] };
type CoursesData = { [key: string]: CourseCategory };


export default function CoursesPage() {
  const [selectedCategory, setSelectedCategory] = React.useState<string>('ai'); // Default to AI
  const [isLoading, setIsLoading] = React.useState(false); // State for loading indicator

   // Simulate loading when tab changes
   const handleTabChange = (value: string) => {
     setIsLoading(true);
     setSelectedCategory(value);
     // Simulate network delay or data fetching time
     setTimeout(() => {
       setIsLoading(false);
     }, 300); // Adjust delay as needed
   };

   const renderRoadmap = (roadmap: RoadmapItem[]) => {
     return (
       <Accordion type="single" collapsible className="w-full" defaultValue="item-0">
         {roadmap.map((item, index) => (
           <AccordionItem value={`item-${index}`} key={index} className="border-b border-border last:border-b-0">
             <AccordionTrigger className="hover:no-underline hover:bg-accent/10 px-4 py-3 rounded-md transition-colors text-left">
               <div className="flex items-center">
                  <span className="mr-3 flex-shrink-0">{item.icon}</span>
                 <div className="flex-grow">
                    <span className="font-medium text-base md:text-lg">{item.title}</span>
                    <p className="text-sm text-muted-foreground font-normal">{item.description}</p>
                 </div>
               </div>
             </AccordionTrigger>
             <AccordionContent className="pt-1 pb-4 px-4 pl-12">
               <ul className="space-y-2.5 list-none">
                 {item.steps.map((step, stepIndex) => (
                   <li key={stepIndex} className="text-sm flex items-center group">
                      <span className="h-1.5 w-1.5 bg-primary rounded-full mr-3 shrink-0 group-hover:bg-accent transition-colors"></span>
                      <TooltipProvider delayDuration={100}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <a
                                href={step.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center text-foreground hover:text-primary hover:underline transition-colors decoration-primary underline-offset-2"
                             >
                              {step.name}
                              <LinkIcon className="h-3.5 w-3.5 ml-1.5 text-muted-foreground opacity-70 group-hover:text-primary transition-colors" />
                            </a>
                          </TooltipTrigger>
                         {step.tooltip && (
                            <TooltipContent side="right" className="bg-popover text-popover-foreground border border-border shadow-lg rounded-md p-2 text-xs max-w-xs z-50">
                               <p>{step.tooltip}</p>
                            </TooltipContent>
                         )}
                        </Tooltip>
                      </TooltipProvider>
                   </li>
                 ))}
               </ul>
             </AccordionContent>
           </AccordionItem>
         ))}
       </Accordion>
     );
   }

   const renderSkeleton = () => (
      <Card className="shadow-md border border-border bg-card animate-pulse">
          <CardHeader className="pb-4">
             <Skeleton className="h-7 w-1/2" /> {/* Title Skeleton */}
          </CardHeader>
          <CardContent className="p-0 space-y-2">
             {[...Array(4)].map((_, index) => ( // Render 4 skeleton accordion items
                 <div key={index} className="border-b border-border last:border-b-0 p-4">
                     <div className="flex items-center justify-between">
                         <div className="flex items-center space-x-3 flex-grow">
                             <Skeleton className="h-5 w-5 rounded-full shrink-0" />
                             <div className="space-y-1.5 flex-grow">
                                 <Skeleton className="h-4 w-3/4" />
                                 <Skeleton className="h-3 w-1/2" />
                             </div>
                         </div>
                         <Skeleton className="h-4 w-4 shrink-0" />
                     </div>
                 </div>
             ))}
          </CardContent>
      </Card>
   );


   const categories = Object.entries(coursesData);
   const gridColsMap: { [key: number]: string } = {
       1: 'grid-cols-1', 2: 'grid-cols-2', 3: 'grid-cols-3',
       4: 'grid-cols-2 sm:grid-cols-4', 5: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-5',
       6: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-6',
   };
   const gridColsClass = gridColsMap[categories.length] || 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6';


   return (
     <div className="space-y-8">
       <h1 className="text-3xl lg:text-4xl font-bold text-center text-primary">Explore Learning Roadmaps</h1>
       <p className="text-center text-muted-foreground max-w-2xl mx-auto">
         Select a category to view a curated learning path with resources to guide your journey in the tech industry. Click on any step to search for relevant learning materials.
       </p>

        <Tabs value={selectedCategory} onValueChange={handleTabChange} className="w-full">
          <TabsList className={`grid w-full h-auto ${gridColsClass} bg-muted p-1 rounded-lg mb-6 gap-1`}>
            {categories.map(([key, { name, icon }]) => (
              <TabsTrigger
                 key={key}
                 value={key}
                 className="data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-md py-2 px-1 transition-all flex items-center justify-center text-xs sm:text-sm whitespace-normal h-full leading-tight"
                 disabled={isLoading} // Disable tabs while loading
              >
                 {React.cloneElement(icon, { className: `${icon.props.className} h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2` })}
                 <span className="text-center">{name}</span>
               </TabsTrigger>
            ))}
          </TabsList>

          {/* Render Skeleton or Content based on isLoading state */}
          {isLoading ? (
               renderSkeleton() // Show skeleton while loading
             ) : (
                 categories.map(([key, { name, roadmap }]) => (
                   <TabsContent key={key} value={key} className="mt-0">
                     <Card className="shadow-md border border-border bg-card">
                       <CardHeader className="pb-4">
                         <CardTitle className="text-2xl text-primary">{name} Roadmap</CardTitle>
                       </CardHeader>
                       <CardContent className="p-0">
                          {renderRoadmap(roadmap)}
                       </CardContent>
                     </Card>
                   </TabsContent>
                 ))
             )}
        </Tabs>
     </div>
   );
 }
    
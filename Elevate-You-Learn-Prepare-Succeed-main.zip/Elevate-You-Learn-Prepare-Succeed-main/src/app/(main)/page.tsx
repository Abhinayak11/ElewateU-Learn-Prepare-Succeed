
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Briefcase, FileText, BrainCircuit, GraduationCap, Github, Linkedin, MessageSquare, Sparkles, Settings, Info, Newspaper } from 'lucide-react'; // Added Newspaper
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import * as React from 'react'; // Import React

// Team members data
const teamMembers = [
  {
    name: 'Rakesh Maragani',
    role: 'Lead Architect & Developer',
    bio: 'Passionate about building helpful applications with cutting-edge AI.',
    imageUrl: '/rakesh.jpg', // Updated image URL
    linkedin: 'https://www.linkedin.com/in/rakesh-maragani-9bb764252',
    github: 'https://github.com/RakeshMaragani',
  },
   {
    name: 'Meghana',
    role: 'UI/UX Designer',
    bio: 'Loves creating beautiful, intuitive, and accessible interfaces.',
    imageUrl: '/meghana.jpg', // Placeholder or actual URL
    linkedin: 'https://www.linkedin.com/in/meghana-kodapaka-6292522a5?',
    github: '#', // Provide GitHub link if available
  },
  {
    name: 'Abhinaya',
    role: 'Backend Developer',
    bio: 'Enjoys tackling complex server-side challenges and optimizing performance.',
    imageUrl: '/abhinaya.jpg', // Placeholder or actual URL
    linkedin: 'https://www.linkedin.com/in/abhinaya-kamatam-811662219?',
    github: 'https://github.com/Abhinayak11',
  },
];

// Define features for the card grid
const features = [
  {
    icon: <BookOpen className="h-8 w-8 text-primary" />,
    title: "Learning Roadmaps",
    description: "Structured paths for AI, ML, Data Science, Full Stack, Cloud, and Cybersecurity.",
    link: "/courses",
    linkText: "Start Learning",
  },
  {
    icon: <FileText className="h-8 w-8 text-primary" />,
    title: "Resume Builder",
    description: "Craft a professional, ATS-compliant resume and download it as a PDF.",
    link: "/resume-builder",
    linkText: "Create Resume",
  },
  {
    icon: <Briefcase className="h-8 w-8 text-primary" />,
    title: "Job Recommendations",
    description: "View sample job suggestions tailored to your profile (Focus: India).",
    link: "/job-recommendations",
    linkText: "Find Jobs",
  },
  {
    icon: <GraduationCap className="h-8 w-8 text-primary" />,
    title: "Mock Interviews",
    description: "Practice common interview questions for various roles.", // Simplified description
    link: "/mock-interviews",
    linkText: "Practice Now",
  },
  {
    icon: <MessageSquare className="h-8 w-8 text-primary" />,
    title: "Community Forum",
    description: "Connect with peers, ask questions, and share knowledge.",
    link: "/community",
    linkText: "Join Discussion",
  },
  {
    icon: <Newspaper className="h-8 w-8 text-primary" />, // Changed icon for Blog
    title: "Blog",
    description: "Read articles on career development, tech trends, and platform updates.",
    link: "/blog",
    linkText: "Read Blog",
  },
   {
    icon: <Settings className="h-8 w-8 text-primary" />,
    title: "User Settings",
    description: "Manage your profile, notifications, and application preferences.",
    link: "/settings",
    linkText: "Go to Settings",
  },
  {
    icon: <Info className="h-8 w-8 text-primary" />,
    title: "About Us",
    description: "Learn more about the mission and vision behind Elevate You.",
    link: "/about",
    linkText: "Learn More",
  },
];

export default function HomePage() {
  return (
    <div className="flex flex-col items-center space-y-16 md:space-y-24"> {/* Increased spacing */}
      {/* Hero Section */}
      <section className="w-full text-center pt-16 pb-20 md:pt-24 md:pb-28 bg-gradient-to-br from-primary via-teal-600 to-cyan-600 rounded-lg shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 bg-black bg-opacity-40 z-0"></div>
         {/* Subtle background elements */}
        <Sparkles className="absolute top-10 left-10 w-16 h-16 text-accent/20 animate-pulse z-0" />
        <BrainCircuit className="absolute bottom-5 right-10 w-20 h-20 text-white/10 z-0 opacity-50 transform rotate-12" />

        <div className="relative z-10 container mx-auto px-4">
           {/* Apply animations using Tailwind config */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white mb-4 tracking-tight animate-fade-in-down">
            Elevate You
          </h1>
          <p className="text-xl sm:text-2xl md:text-3xl text-gray-200 mb-10 animate-fade-in-up font-light">
            Learn the Skills. Build the Resume. Land the Job.
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in">
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 transition-transform transform hover:scale-105 shadow-md px-8 py-3">
              <Link href="/courses">Explore Courses</Link>
            </Button>
            <Button asChild size="lg" className="bg-white text-primary hover:bg-gray-100 transition-transform transform hover:scale-105 shadow-md px-8 py-3">
              <Link href="/resume-builder">Build Resume</Link>
            </Button>
             {/* Updated Button for Job Recommendations */}
            <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800 transition-transform transform hover:scale-105 shadow-md px-8 py-3 mt-4 sm:mt-0">
              <Link href="/job-recommendations">Get Job Recommendations</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="w-full max-w-4xl text-center space-y-4 px-4">
        <h2 className="text-3xl md:text-4xl font-semibold text-foreground">Your Complete Career Toolkit</h2>
        <p className="text-lg text-muted-foreground leading-relaxed">
          Navigate your tech career journey with confidence. Elevate You offers curated learning paths,
          an ATS-friendly resume builder, AI-powered job recommendations, and interview practice – all in one place.
        </p>
      </section>

      {/* Features Overview */}
      <section className="w-full max-w-6xl px-4">
        <h3 className="text-2xl font-semibold text-center mb-10 text-primary">What We Offer</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={feature.title + index} // Ensure unique key even if titles repeat
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              link={feature.link}
              linkText={feature.linkText}
            />
          ))}
        </div>
      </section>

       {/* Team Section */}
        <section className="w-full max-w-5xl mt-16 px-4">
          <h2 className="text-3xl font-semibold text-center mb-10 text-primary">Meet the Team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 justify-items-center">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center flex flex-col items-center max-w-xs p-6 bg-card rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 border border-border">
                 <Avatar className="w-24 h-24 mb-4 shadow-lg border-2 border-primary">
                   <AvatarImage src={member.imageUrl} alt={member.name} />
                   <AvatarFallback>{member.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                 </Avatar>
                <h3 className="text-lg font-medium text-foreground">{member.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">{member.role}</p>
                <p className="text-sm text-center mb-3 text-card-foreground px-2">{member.bio}</p>
                <div className="flex space-x-4 mt-auto pt-3 border-t border-border w-full justify-center"> {/* Added border and spacing */}
                   <a href={member.linkedin} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors" aria-label={`${member.name}'s LinkedIn Profile`}>
                    <Linkedin size={20} />
                  </a>
                  <a href={member.github} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors" aria-label={`${member.name}'s GitHub Profile`}>
                    <Github size={20} />
                  </a>
                </div>
             </div>
            ))}
          </div>
        </section>
    </div>
  );
}

// FeatureCard Component Definition
interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
  linkText: string;
}

function FeatureCard({ icon, title, description, link, linkText }: FeatureCardProps) {
    return (
        <Card className="shadow-md hover:shadow-lg transition-shadow duration-300 flex flex-col bg-card border border-border group"> {/* Added group */}
            <CardHeader className="flex flex-col items-center text-center gap-4 pb-3 pt-6"> {/* Centered items */}
                <div className="bg-primary/10 p-3 rounded-full text-primary group-hover:bg-accent/10 group-hover:text-accent transition-colors"> {/* Icon background */}
                    {icon}
                </div>
                <CardTitle className="text-xl">{title}</CardTitle>
            </CardHeader>
            <CardContent className="flex-grow text-center px-6"> {/* Centered text */}
                <CardDescription>{description}</CardDescription>
            </CardContent>
            <div className="p-6 pt-2 mt-auto text-center"> {/* Ensure button is at the bottom and centered */}
                <Button asChild variant="link" className="p-0 h-auto text-primary group-hover:text-accent transition-colors font-medium">
                    <Link href={link}>{linkText}</Link>
                </Button>
            </div>
        </Card>
    );
}

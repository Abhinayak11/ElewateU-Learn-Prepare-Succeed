"use client";

import * as React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { ArrowLeft, Calendar } from 'lucide-react';
import OptimizedImage from '@/components/ui/image'; // Import OptimizedImage
import { Skeleton } from '@/components/ui/skeleton'; // For loading state

// Mock blog posts data (should match the data in BlogPage)
const blogPosts = [
  {
    id: 1,
    title: "Mastering React Hooks: A Deep Dive",
    excerpt: "Unlock the full potential of React Hooks. Learn about useState, useEffect, useContext, and custom hooks with practical examples.",
    content: `
React Hooks revolutionized how we write components. Let's dive deeper...

### useState
The \`useState\` hook allows functional components to manage local state.

\`\`\`jsx
const [count, setCount] = useState(0);
\`\`\`

### useEffect
\`useEffect\` lets you perform side effects in function components. Think data fetching, subscriptions, or manually changing the DOM.

\`\`\`jsx
useEffect(() => {
  // Runs after every render
  document.title = \`You clicked \${count} times\`;

  // Cleanup function (optional)
  return () => {
    // Clean up the effect
  };
}, [count]); // Only re-run if count changes
\`\`\`

### useContext
\`useContext\` provides a way to pass data through the component tree without having to pass props down manually at every level.

(More detailed content about useContext and custom hooks would go here...)
    `,
    date: "2024-07-15",
    author: "AI Assistant",
    slug: "mastering-react-hooks",
    imageUrl: "https://picsum.photos/seed/reacthooks-v3/800/400", // Updated seed
  },
  {
    id: 2,
    title: "The Future of AI: Trends to Watch in 2025",
    excerpt: "Explore the cutting-edge advancements in Artificial Intelligence, from large language models to generative AI applications.",
    content: `
Artificial Intelligence continues to evolve at an unprecedented pace. Here are some key trends shaping its future:

*   **Large Language Models (LLMs):** Models like GPT-4 and beyond are becoming more capable, impacting various industries.
*   **Generative AI:** Beyond text, AI is generating realistic images, music, and even code.
*   **AI Ethics and Regulation:** Growing focus on responsible AI development and deployment.
*   **AI in Scientific Discovery:** Accelerating research in medicine, climate science, and more.

(Each point would be expanded with more detail and examples...)
    `,
    date: "2024-07-10",
    author: "AI Assistant",
    slug: "future-of-ai-2025",
    imageUrl: "https://picsum.photos/seed/aifuture-v3/800/400", // Updated seed
  },
  {
    id: 3,
    title: "Building Your First Full Stack Application",
    excerpt: "A step-by-step guide to creating a full-stack web application using Node.js, Express, React, and MongoDB.",
    content: `
Ready to build a complete web application? Let's outline the steps:

1.  **Setup Backend (Node.js & Express):** Initialize project, install dependencies, create server file, define basic routes.
2.  **Database Integration (MongoDB):** Connect to MongoDB using Mongoose, define schemas and models.
3.  **API Development:** Create CRUD (Create, Read, Update, Delete) endpoints for your data.
4.  **Setup Frontend (React):** Use Create React App or Vite, set up components and routing.
5.  **Connect Frontend & Backend:** Use \`fetch\` or \`axios\` to make API calls from React to your Express server.
6.  **Deployment:** Choose a hosting platform (e.g., Vercel, Netlify, Heroku) and deploy both frontend and backend.

(This is a high-level overview; each step involves significant detail and code...)
    `,
    date: "2024-07-05",
    author: "AI Assistant",
    slug: "first-full-stack-app",
    imageUrl: "https://picsum.photos/seed/fullstack-v3/800/400", // Updated seed
  },
   {
    id: 4,
    title: "Resume Writing Tips for Tech Professionals",
    excerpt: "Craft an ATS-friendly resume that highlights your skills and experience effectively to land your dream tech job.",
    content: `
Getting past the Applicant Tracking System (ATS) and impressing recruiters requires a well-crafted resume. Key tips:

*   **Keywords:** Tailor keywords from the job description throughout your resume.
*   **Standard Formatting:** Use clear headings (Summary, Experience, Education, Skills) and standard fonts. Avoid tables and columns.
*   **Quantify Achievements:** Instead of just listing duties, show impact (e.g., "Increased performance by 15% by implementing X").
*   **Skills Section:** Include both technical (programming languages, tools) and soft skills.
*   **Conciseness:** Aim for one page, especially if you have less than 10 years of experience. Two pages are acceptable for senior roles.
*   **File Format:** Save as PDF unless otherwise specified.

(Include examples and more detailed explanations for each point...)
    `,
    date: "2024-06-28",
    author: "Career Coach Bot",
    slug: "resume-tips-tech",
    imageUrl: "https://picsum.photos/seed/resumetips-v3/800/400", // Updated seed
  },
   {
    id: 5,
    title: "Demystifying Cloud Computing: AWS vs Azure vs GCP",
    excerpt: "Understand the key differences, pros, and cons of the major cloud providers to choose the right one for your needs.",
    content: `
Choosing a cloud provider is a critical decision. Here's a brief comparison:

*   **Amazon Web Services (AWS):** Largest market share, extensive service portfolio, mature ecosystem. Can have complex pricing.
*   **Microsoft Azure:** Strong in enterprise, excellent hybrid cloud capabilities, integrates well with Microsoft products. Steeper learning curve for some services compared to AWS equivalents initially.
*   **Google Cloud Platform (GCP):** Strengths in data analytics, machine learning, and Kubernetes (GKE). Smaller market share but often competitive pricing.

**Factors to Consider:** Existing infrastructure, team expertise, specific service needs (e.g., AI/ML, data warehousing), pricing models, compliance requirements.

(Expand on specific services, pricing nuances, and use cases for each provider...)
    `,
    date: "2024-06-20",
    author: "Cloud Expert AI",
    slug: "cloud-comparison",
    imageUrl: "https://picsum.photos/seed/cloud-v3/800/400", // Updated seed
  },
];

export default function BlogPostPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [post, setPost] = React.useState<typeof blogPosts[0] | null | undefined>(undefined); // Initial state undefined
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (slug) {
      setLoading(true);
      // Simulate fetching data - find the post based on the slug
      const foundPost = blogPosts.find(p => p.slug === slug);
      // Simulate network delay
      const timer = setTimeout(() => {
        setPost(foundPost || null); // Set to null if not found
        setLoading(false);
      }, 300); // 300ms delay

      return () => clearTimeout(timer); // Cleanup timer on unmount or slug change
    } else {
      setLoading(false); // No slug, not loading
      setPost(null); // No slug, no post
    }
  }, [slug]);

  if (loading || post === undefined) { // Show skeleton while loading OR if post state is still initial undefined
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-pulse">
         <Skeleton className="h-10 w-3/4" /> {/* Title */}
         <Skeleton className="h-6 w-1/2" /> {/* Meta */}
         <Skeleton className="h-64 w-full md:h-80" /> {/* Image */}
         <div className="space-y-4">
             <Skeleton className="h-4 w-full" />
             <Skeleton className="h-4 w-full" />
             <Skeleton className="h-4 w-5/6" />
             <Skeleton className="h-4 w-full" />
             <Skeleton className="h-4 w-3/4" />
         </div>
          <Skeleton className="h-10 w-32" /> {/* Back button */}
      </div>
    );
  }

  if (post === null) { // Explicitly check for null (post not found after fetch attempt)
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-destructive mb-4">Post Not Found</h1>
        <p className="text-muted-foreground mb-6">Sorry, we couldn't find the blog post you were looking for.</p>
        <Button asChild>
          <Link href="/blog">
             <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
          </Link>
        </Button>
      </div>
    );
  }

  // Post is found and loaded
  return (
    <div className="max-w-4xl mx-auto">
      <Card className="overflow-hidden shadow-lg">
         <CardHeader className="p-0">
             <div className="relative w-full h-64 md:h-80"> {/* Adjusted height */}
                 <OptimizedImage
                     src={post.imageUrl}
                     alt={post.title}
                     fill // Use fill instead of layout
                     style={{ objectFit: 'cover' }} // Use style object for objectFit
                     priority // Prioritize loading the main image
                     sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 800px" // Add sizes prop
                 />
             </div>
         </CardHeader>
         <CardContent className="p-6 md:p-8">
             <Button asChild variant="outline" size="sm" className="mb-6">
                 <Link href="/blog">
                     <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
                 </Link>
             </Button>
           <CardTitle className="text-3xl md:text-4xl font-bold text-primary mb-3">{post.title}</CardTitle>
           <CardDescription className="text-base text-muted-foreground mb-6 flex items-center">
             <Calendar className="h-4 w-4 mr-1.5" /> {post.date} • By {post.author}
           </CardDescription>

           {/* Render post content - Use standard Tailwind classes */}
           {/* For advanced markdown rendering, use a library like react-markdown */}
           <article className="space-y-4 text-foreground">
              {post.content.split('\n').map((paragraph, index) => {
                 const trimmedParagraph = paragraph.trim();
                 if (!trimmedParagraph) return <br key={index} />; // Render breaks for empty lines

                 // Basic heuristic for headings
                 if (trimmedParagraph.startsWith('### ')) {
                     return <h3 key={index} className="text-xl font-semibold mt-6 mb-2 text-primary">{trimmedParagraph.substring(4)}</h3>;
                 }
                  if (trimmedParagraph.startsWith('## ')) {
                     return <h2 key={index} className="text-2xl font-semibold mt-8 mb-3 border-b pb-1 text-primary">{trimmedParagraph.substring(3)}</h2>;
                 }
                 // Basic list item detection
                  if (trimmedParagraph.startsWith('*   ')) {
                     return <li key={index} className="ml-6 list-disc">{trimmedParagraph.substring(4)}</li>;
                 }
                  // Basic code block detection (no syntax highlighting)
                  if (trimmedParagraph.startsWith('```')) {
                       const isClosingTag = trimmedParagraph.endsWith('```');
                       const codeContent = trimmedParagraph.substring(3, trimmedParagraph.length - (isClosingTag ? 3 : 0));
                       // Check if it's likely the start or end of a block to avoid rendering ```jsx etc. as content
                       if (codeContent.length < 10 && !codeContent.includes(' ')) {
                           return null; // Don't render the ```jsx line itself
                       }
                      return <pre key={index} className="bg-muted p-3 rounded-md overflow-x-auto my-4"><code className="font-mono text-sm">{codeContent}</code></pre>;
                  }

                 // Default to paragraph
                 return <p key={index}>{trimmedParagraph}</p>;
              })}
           </article>

         </CardContent>
      </Card>
    </div>
  );
}

"use client";

import * as React from 'react';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { ArrowRight, Calendar } from 'lucide-react';
import OptimizedImage from '@/components/ui/image'; // Import OptimizedImage

// Mock blog posts data
const blogPosts = [
  {
    id: 1,
    title: "Mastering React Hooks: A Deep Dive",
    excerpt: "Unlock the full potential of React Hooks. Learn about useState, useEffect, useContext, and custom hooks with practical examples.",
    date: "2024-07-15",
    author: "AI Assistant",
    slug: "mastering-react-hooks",
    imageUrl: "https://picsum.photos/seed/reacthooks-v2/600/400", // Updated seed
  },
  {
    id: 2,
    title: "The Future of AI: Trends to Watch in 2025",
    excerpt: "Explore the cutting-edge advancements in Artificial Intelligence, from large language models to generative AI applications.",
    date: "2024-07-10",
    author: "AI Assistant",
    slug: "future-of-ai-2025",
     imageUrl: "https://picsum.photos/seed/aifuture-v2/600/400", // Updated seed
  },
  {
    id: 3,
    title: "Building Your First Full Stack Application",
    excerpt: "A step-by-step guide to creating a full-stack web application using Node.js, Express, React, and MongoDB.",
    date: "2024-07-05",
    author: "AI Assistant",
    slug: "first-full-stack-app",
     imageUrl: "https://picsum.photos/seed/fullstack-v2/600/400", // Updated seed
  },
   {
    id: 4,
    title: "Resume Writing Tips for Tech Professionals",
    excerpt: "Craft an ATS-friendly resume that highlights your skills and experience effectively to land your dream tech job.",
    date: "2024-06-28",
    author: "Career Coach Bot",
    slug: "resume-tips-tech",
     imageUrl: "https://picsum.photos/seed/resumetips-v2/600/400", // Updated seed
  },
   {
    id: 5,
    title: "Demystifying Cloud Computing: AWS vs Azure vs GCP",
    excerpt: "Understand the key differences, pros, and cons of the major cloud providers to choose the right one for your needs.",
    date: "2024-06-20",
    author: "Cloud Expert AI",
    slug: "cloud-comparison",
     imageUrl: "https://picsum.photos/seed/cloud-v2/600/400", // Updated seed
  },
];

export default function BlogPage() {
  return (
    <div className="space-y-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-primary mb-2">Elevate You Blog</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Insights, tutorials, and career advice to help you grow in the tech industry.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map((post) => (
          <Card key={post.id} className="flex flex-col overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 group bg-card"> {/* Added bg-card */}
             <CardHeader className="p-0">
               {/* Use next/image for optimization */}
               <div className="relative w-full h-48 overflow-hidden"> {/* Added overflow-hidden */}
                  <OptimizedImage
                      src={post.imageUrl}
                      alt={post.title}
                      fill // Use fill instead of layout
                      style={{ objectFit: 'cover' }} // Use style object for objectFit
                      className="transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" // Add sizes prop
                      loading="lazy"
                  />
               </div>
             </CardHeader>
             <CardContent className="p-6 flex-grow flex flex-col">
               <CardTitle className="text-xl mb-2 text-primary group-hover:text-accent transition-colors">{post.title}</CardTitle>
               <CardDescription className="text-sm text-muted-foreground mb-3 flex items-center">
                 <Calendar className="h-4 w-4 mr-1.5" /> {post.date} • By {post.author}
               </CardDescription>
               <p className="text-sm text-card-foreground flex-grow">{post.excerpt}</p>
             </CardContent>
             <CardFooter className="p-6 pt-0 mt-auto">
               <Button asChild variant="link" className="p-0 h-auto text-primary hover:text-accent">
                  <Link href={`/blog/${post.slug}`}>
                   Read More <ArrowRight className="ml-1 h-4 w-4" />
                 </Link>
               </Button>
             </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}

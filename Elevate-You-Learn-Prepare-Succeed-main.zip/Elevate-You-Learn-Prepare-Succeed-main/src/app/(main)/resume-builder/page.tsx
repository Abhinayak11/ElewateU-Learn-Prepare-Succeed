"use client";

import * as React from "react";
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, PlusCircle, Trash2, Linkedin, Loader2, Eye, EyeOff } from 'lucide-react';
import jsPDF from "jspdf";
import html2canvas from 'html2canvas';
import { useToast } from "@/hooks/use-toast";
import placeholderData from '@/lib/linkedin-placeholder'; // Import the placeholder data

// Zod Schema for Validation
const resumeSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  jobTitle: z.string().min(1, 'Job title or headline is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().optional(),
  linkedin: z.string().url('Invalid URL (e.g., https://linkedin.com/in/...)').optional().or(z.literal('')),
  github: z.string().url('Invalid URL (e.g., https://github.com/...)').optional().or(z.literal('')),
  portfolio: z.string().url('Invalid URL').optional().or(z.literal('')),
  summary: z.string().min(10, 'Summary should be at least 10 characters').max(600, 'Summary should be concise (max 600 characters)'),
  education: z.array(z.object({
    institution: z.string().min(1, 'Institution is required'),
    degree: z.string().min(1, 'Degree/Major is required'),
    startDate: z.string().min(1, 'Start date is required'),
    endDate: z.string().min(1, 'End date/Expected is required'),
    details: z.string().optional(),
  })).min(1, 'At least one education entry is required'),
  experience: z.array(z.object({
    company: z.string().min(1, 'Company is required'),
    position: z.string().min(1, 'Position is required'),
    startDate: z.string().min(1, 'Start date is required'),
    endDate: z.string().min(1, 'End date or Present is required'),
    responsibilities: z.string().min(1, 'Responsibilities/Achievements are required (use bullet points)'),
  })).min(1, 'At least one experience entry is required'),
  skills: z.array(z.object({ name: z.string().min(1, 'Skill name cannot be empty') })).min(1, 'At least one skill is required'),
  certifications: z.array(z.object({
      name: z.string().min(1, 'Certification name cannot be empty'),
      issuer: z.string().optional(),
      date: z.string().optional() })
  ).optional(),
  projects: z.array(z.object({
      name: z.string().min(1, 'Project name cannot be empty'),
      description: z.string().min(1, 'Description is required (use bullet points)'),
      link: z.string().url('Invalid URL').optional().or(z.literal('')) })
  ).optional(),
});

type ResumeFormData = z.infer<typeof resumeSchema>;

// Helper to format year/date strings to YYYY-MM for input type=month
// Handles YYYY, YYYY-MM, YYYY-MM-DD
const formatToYearMonth = (dateStr: string | number | null | undefined): string => {
    if (!dateStr) return '';
    const str = String(dateStr);
    if (/^\d{4}$/.test(str)) { // Just year
        return `${str}-01`; // Assume January if only year is given
    }
    if (/^\d{4}-\d{2}$/.test(str)) { // Already YYYY-MM
        return str;
    }
     if (/^\d{4}-\d{2}-\d{2}$/.test(str)) { // YYYY-MM-DD
        return str.substring(0, 7); // Extract YYYY-MM
    }
    return ''; // Invalid format
};

// Helper to format experience end date (null means 'Present')
const formatExperienceEndDate = (dateStr: string | null | undefined): string => {
    if (dateStr === null || dateStr === undefined) {
        return "Present";
    }
    return formatToYearMonth(dateStr) || "Present"; // Fallback to Present if formatting fails
};

export default function ResumeBuilderPage() {
  const { register, control, handleSubmit, formState: { errors }, watch, reset, setValue } = useForm<ResumeFormData>({
    resolver: zodResolver(resumeSchema),
    defaultValues: { // Initialize with empty or default values
        fullName: '', jobTitle: '', email: '', phone: '', linkedin: '', github: '', portfolio: '', summary: '',
        education: [{ institution: '', degree: '', startDate: '', endDate: '', details: '' }],
        experience: [{ company: '', position: '', startDate: '', endDate: '', responsibilities: '' }],
        skills: [{ name: '' }],
        certifications: [],
        projects: [],
    }
  });

    const { toast } = useToast();
    const [isImporting, setIsImporting] = React.useState(false); // State for import loading

    // Function to populate form with placeholder data
    const importLinkedInPlaceholder = () => {
        setIsImporting(true);
        try {
            // Reset form partially to clear arrays before appending new data
            reset({
                ...watch(), // Keep existing non-array fields if desired, or specify defaults
                education: [],
                experience: [],
                skills: [],
                certifications: [],
                projects: []
            }, { keepDefaultValues: false }); // Avoid resetting to initial defaults if some fields were edited

            // Use setValue for simple fields
            setValue("fullName", `${placeholderData.firstName} ${placeholderData.lastName}`);
            setValue("jobTitle", placeholderData.headline);
            setValue("email", placeholderData.email);
            setValue("phone", placeholderData.phone);
            // Add LinkedIn URL if available in placeholder data (assuming it exists)
            // setValue("linkedin", placeholderData.linkedinUrl || ''); // Example if URL was in data
            setValue("summary", placeholderData.summary);

             // Set array fields - Use append with mapped data
             placeholderData.education.forEach(edu => {
                appendEducation({
                    institution: edu.schoolName,
                    degree: `${edu.degree}, ${edu.fieldOfStudy}`, // Combine degree and field
                    startDate: formatToYearMonth(edu.startYear),
                    endDate: formatToYearMonth(edu.endYear),
                    details: '', // No direct mapping for details in placeholder
                });
            });

             placeholderData.experience.forEach(exp => {
                 appendExperience({
                    company: exp.companyName,
                    position: exp.title,
                    startDate: formatToYearMonth(exp.startDate),
                    endDate: formatExperienceEndDate(exp.endDate), // Handle 'Present'
                    responsibilities: exp.description, // Assuming description contains responsibilities
                });
             });

             placeholderData.skills.forEach(skill => {
                 appendSkill({ name: skill });
             });

             placeholderData.certifications.forEach(cert => {
                 appendCertification({
                     name: cert.name,
                     issuer: cert.issuingOrganization,
                     date: formatToYearMonth(cert.issueDate), // Format issue date
                 });
             });

             placeholderData.projects.forEach(proj => {
                appendProject({
                    name: proj.name,
                    description: proj.description,
                    link: proj.url || '',
                });
             });


            toast({
                title: "Placeholder Data Imported",
                description: "Resume fields populated with sample LinkedIn data (Demo).",
            });
        } catch (error) {
             console.error("Error importing placeholder data:", error);
            toast({
                title: "Import Failed",
                description: "Could not populate form with placeholder data.",
                variant: "destructive",
            });
        } finally {
            setIsImporting(false);
        }
    };

    // Field array controls
    const { fields: educationFields, append: appendEducation, remove: removeEducation } = useFieldArray({ control, name: 'education' });
    const { fields: experienceFields, append: appendExperience, remove: removeExperience } = useFieldArray({ control, name: 'experience' });
    const { fields: skillsFields, append: appendSkill, remove: removeSkill } = useFieldArray({ control, name: 'skills' });
    const { fields: certificationFields, append: appendCertification, remove: removeCertification } = useFieldArray({ control, name: 'certifications' });
    const { fields: projectFields, append: appendProject, remove: removeProject } = useFieldArray({ control, name: 'projects' });

    const resumePreviewRef = React.useRef<HTMLDivElement>(null);
    const [isDownloading, setIsDownloading] = React.useState(false);
    const [showPreview, setShowPreview] = React.useState(false);
    const formData = watch();

  const handleDownloadPdf = async () => {
    const input = resumePreviewRef.current;
    if (!input) {
      toast({ title: "Error", description: "Preview element not found.", variant: "destructive" });
      return;
    }

    setIsDownloading(true);
    toast({ title: "Generating PDF...", description: "Please wait while your resume is being prepared." });

    const wasPreviewVisible = showPreview;
    if (!wasPreviewVisible) {
        setShowPreview(true);
        await new Promise(resolve => setTimeout(resolve, 200));
    }

    const targetElement = resumePreviewRef.current;
    if (!targetElement) {
        toast({ title: "Error", description: "Preview element disappeared during generation.", variant: "destructive" });
        setIsDownloading(false);
        setShowPreview(wasPreviewVisible);
        return;
    }

    try {
      const canvas = await html2canvas(targetElement, {
        scale: 2.5,
        useCORS: true,
        logging: false,
         onclone: (document) => {
            const preview = document.getElementById('resume-preview-content');
            if (preview) {
                preview.style.width = '800px';
            }
        }
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
          orientation: 'p', unit: 'mm', format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgProps = pdf.getImageProperties(imgData);
      const imgWidth = imgProps.width;
      const imgHeight = imgProps.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = 0;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${formData.fullName?.replace(/\s+/g, '_') || 'resume'}_ElevateYou.pdf`);
      toast({ title: "Download Complete", description: "Your resume PDF has been generated." });

    } catch (err) {
      console.error("Error generating PDF:", err);
      toast({ title: "PDF Generation Failed", description: "Could not generate the resume PDF. Please try again.", variant: "destructive" });
    } finally {
       setIsDownloading(false);
        if (!wasPreviewVisible) {
            setShowPreview(false);
        }
    }
  };

  const onSubmit = (data: ResumeFormData) => {
    console.log("Resume Data Submitted (for generation):", data);
    handleDownloadPdf();
  };

  const renderBulletPoints = (text: string | undefined) => {
      if (!text) return null;
      return (
          <ul className="list-disc pl-5 space-y-1">
              {text.split('\n')
                  .map(line => line.trim().replace(/^- /, ''))
                  .filter(line => line)
                  .map((line, index) => <li key={index}>{line}</li>)
              }
          </ul>
      );
  };


  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-primary">Resume Builder</h1>
        <p className="text-muted-foreground">Create a professional, ATS-friendly resume. Fill in the sections below.</p>
         <div className="flex justify-center items-center space-x-4 mt-4">
             {/* Updated LinkedIn Import Button */}
            <Button type="button" variant="secondary" onClick={importLinkedInPlaceholder} disabled={isImporting}>
                {isImporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Linkedin className="mr-2 h-4 w-4" />}
                {isImporting ? 'Importing...' : 'Import LinkedIn (Demo Data)'}
            </Button>
             <Button variant="outline" size="sm" onClick={() => setShowPreview(!showPreview)}>
                {showPreview ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                {showPreview ? 'Hide Preview' : 'Show Preview'}
            </Button>
         </div>
      </div>

       {/* Resume Form */}
       <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
         {/* Personal Information */}
        <Card>
          <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label htmlFor="fullName">Full Name</Label><Input id="fullName" {...register('fullName')} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.fullName?.message}</p></div>
            <div><Label htmlFor="jobTitle">Job Title / Headline</Label><Input id="jobTitle" {...register('jobTitle')} placeholder="e.g., Software Engineer" aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.jobTitle?.message}</p></div>
            <div><Label htmlFor="email">Email Address</Label><Input id="email" type="email" {...register('email')} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.email?.message}</p></div>
            <div><Label htmlFor="phone">Phone Number (Optional)</Label><Input id="phone" type="tel" {...register('phone')} /></div>
            <div><Label htmlFor="linkedin">LinkedIn Profile URL (Optional)</Label><Input id="linkedin" placeholder="https://linkedin.com/in/yourprofile" {...register('linkedin')} /><p className="text-destructive text-xs mt-1">{errors.linkedin?.message}</p></div>
            <div><Label htmlFor="github">GitHub Profile URL (Optional)</Label><Input id="github" placeholder="https://github.com/yourusername" {...register('github')} /><p className="text-destructive text-xs mt-1">{errors.github?.message}</p></div>
            <div className="md:col-span-2"><Label htmlFor="portfolio">Portfolio URL (Optional)</Label><Input id="portfolio" placeholder="https://yourportfolio.com" {...register('portfolio')} /><p className="text-destructive text-xs mt-1">{errors.portfolio?.message}</p></div>
            <div className="md:col-span-2"><Label htmlFor="summary">Professional Summary</Label><Textarea id="summary" {...register('summary')} rows={4} placeholder="Briefly highlight your key skills, experience, and career goals (2-4 sentences)." aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.summary?.message}</p></div>
          </CardContent>
        </Card>

        {/* Experience Section */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>Work Experience</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => appendExperience({ company: '', position: '', startDate: '', endDate: '', responsibilities: '' })}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Experience
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {experienceFields.map((field, index) => (
              <div key={field.id} className="space-y-3 p-4 border rounded-md relative bg-background/50">
                 <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => removeExperience(index)} aria-label="Remove Experience Entry">
                  <Trash2 className="h-4 w-4" />
                 </Button>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><Label htmlFor={`experience.${index}.company`}>Company</Label><Input id={`experience.${index}.company`} {...register(`experience.${index}.company`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.experience?.[index]?.company?.message}</p></div>
                  <div><Label htmlFor={`experience.${index}.position`}>Position</Label><Input id={`experience.${index}.position`} {...register(`experience.${index}.position`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.experience?.[index]?.position?.message}</p></div>
                  <div><Label htmlFor={`experience.${index}.startDate`}>Start Date</Label><Input id={`experience.${index}.startDate`} type="month" {...register(`experience.${index}.startDate`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.experience?.[index]?.startDate?.message}</p></div>
                  <div><Label htmlFor={`experience.${index}.endDate`}>End Date</Label><Input id={`experience.${index}.endDate`} type="text" {...register(`experience.${index}.endDate`)} placeholder="YYYY-MM or Present" aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.experience?.[index]?.endDate?.message}</p></div>
                  <div className="md:col-span-2"><Label htmlFor={`experience.${index}.responsibilities`}>Responsibilities / Achievements</Label><Textarea id={`experience.${index}.responsibilities`} {...register(`experience.${index}.responsibilities`)} rows={5} placeholder="Start each point on a new line. Use action verbs (e.g., Developed, Managed, Increased...). Quantify achievements where possible." aria-required="true"/><p className="text-destructive text-xs mt-1">{errors.experience?.[index]?.responsibilities?.message}</p></div>
                 </div>
              </div>
            ))}
            {(errors.experience?.root || (errors.experience as any)?.message) && <p className="text-destructive text-xs mt-1">{errors.experience?.root?.message || (errors.experience as any)?.message}</p>}
          </CardContent>
        </Card>

        {/* Education Section */}
         <Card>
           <CardHeader className="flex flex-row justify-between items-center">
             <CardTitle>Education</CardTitle>
             <Button type="button" variant="outline" size="sm" onClick={() => appendEducation({ institution: '', degree: '', startDate: '', endDate: '', details: '' })}>
               <PlusCircle className="mr-2 h-4 w-4" /> Add Education
             </Button>
           </CardHeader>
           <CardContent className="space-y-4">
             {educationFields.map((field, index) => (
               <div key={field.id} className="space-y-3 p-4 border rounded-md relative bg-background/50">
                  <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => removeEducation(index)} aria-label="Remove Education Entry">
                   <Trash2 className="h-4 w-4" />
                 </Button>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div><Label htmlFor={`education.${index}.institution`}>Institution</Label><Input id={`education.${index}.institution`} {...register(`education.${index}.institution`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.education?.[index]?.institution?.message}</p></div>
                   <div><Label htmlFor={`education.${index}.degree`}>Degree / Major</Label><Input id={`education.${index}.degree`} {...register(`education.${index}.degree`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.education?.[index]?.degree?.message}</p></div>
                   <div><Label htmlFor={`education.${index}.startDate`}>Start Date</Label><Input id={`education.${index}.startDate`} type="month" {...register(`education.${index}.startDate`)} aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.education?.[index]?.startDate?.message}</p></div>
                   <div><Label htmlFor={`education.${index}.endDate`}>End Date / Expected</Label><Input id={`education.${index}.endDate`} type="text" {...register(`education.${index}.endDate`)} placeholder="YYYY-MM or Expected YYYY-MM" aria-required="true" /><p className="text-destructive text-xs mt-1">{errors.education?.[index]?.endDate?.message}</p></div>
                   <div className="md:col-span-2"><Label htmlFor={`education.${index}.details`}>Relevant Coursework / Honors (Optional)</Label><Textarea id={`education.${index}.details`} {...register(`education.${index}.details`)} rows={2} /></div>
                 </div>
               </div>
             ))}
              {(errors.education?.root || (errors.education as any)?.message) && <p className="text-destructive text-xs mt-1">{errors.education?.root?.message || (errors.education as any)?.message}</p>}
           </CardContent>
        </Card>

         {/* Skills Section */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>Skills</CardTitle>
             <Button type="button" variant="outline" size="sm" onClick={() => appendSkill({ name: '' })}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Skill
            </Button>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {skillsFields.map((field, index) => (
               <div key={field.id} className="flex items-center gap-1 bg-secondary p-1 rounded">
                 <Input
                    {...register(`skills.${index}.name`)}
                    className="h-8 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 w-auto min-w-[80px] text-sm"
                    placeholder="Skill"
                    aria-label={`Skill ${index + 1}`}
                  />
                  <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => removeSkill(index)} aria-label={`Remove Skill ${index + 1}`}>
                   <Trash2 className="h-4 w-4" />
                 </Button>
                  {errors.skills?.[index]?.name && <p className="text-destructive text-xs">{errors.skills?.[index]?.name?.message}</p>}
               </div>
            ))}
             {(errors.skills?.root || (errors.skills as any)?.message) && <p className="text-destructive text-xs mt-1 w-full">{errors.skills?.root?.message || (errors.skills as any)?.message}</p>}
             <CardDescription className="w-full text-xs mt-2">Enter technical skills (e.g., Python, AWS, Figma) and relevant soft skills (e.g., Communication, Teamwork).</CardDescription>
          </CardContent>
        </Card>

         {/* Projects Section (Optional) */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>Projects (Optional)</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => appendProject({ name: '', description: '', link: '' })}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Project
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {projectFields.map((field, index) => (
              <div key={field.id} className="space-y-3 p-4 border rounded-md relative bg-background/50">
                 <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => removeProject(index)} aria-label="Remove Project Entry">
                  <Trash2 className="h-4 w-4" />
                </Button>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div><Label htmlFor={`projects.${index}.name`}>Project Name</Label><Input id={`projects.${index}.name`} {...register(`projects.${index}.name`)} /><p className="text-destructive text-xs mt-1">{errors.projects?.[index]?.name?.message}</p></div>
                   <div><Label htmlFor={`projects.${index}.link`}>Project Link (Optional)</Label><Input id={`projects.${index}.link`} {...register(`projects.${index}.link`)} placeholder="https://github.com/your/repo or https://livedemo.com" /><p className="text-destructive text-xs mt-1">{errors.projects?.[index]?.link?.message}</p></div>
                   <div className="md:col-span-2"><Label htmlFor={`projects.${index}.description`}>Description / Key Features</Label><Textarea id={`projects.${index}.description`} {...register(`projects.${index}.description`)} rows={4} placeholder="Describe the project and your role. Use bullet points for key contributions or technologies used." /><p className="text-destructive text-xs mt-1">{errors.projects?.[index]?.description?.message}</p></div>
                 </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Certifications Section (Optional) */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>Certifications (Optional)</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => appendCertification({ name: '', issuer: '', date: '' })}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Certification
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {certificationFields.map((field, index) => (
              <div key={field.id} className="space-y-3 p-4 border rounded-md relative bg-background/50">
                 <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => removeCertification(index)} aria-label="Remove Certification Entry">
                  <Trash2 className="h-4 w-4" />
                </Button>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   <div className="md:col-span-2"><Label htmlFor={`certifications.${index}.name`}>Certification Name</Label><Input id={`certifications.${index}.name`} {...register(`certifications.${index}.name`)} /><p className="text-destructive text-xs mt-1">{errors.certifications?.[index]?.name?.message}</p></div>
                   <div><Label htmlFor={`certifications.${index}.issuer`}>Issuing Organization (Optional)</Label><Input id={`certifications.${index}.issuer`} {...register(`certifications.${index}.issuer`)} /></div>
                   <div><Label htmlFor={`certifications.${index}.date`}>Date Received (Optional)</Label><Input id={`certifications.${index}.date`} type="month" {...register(`certifications.${index}.date`)} /></div>
                 </div>
              </div>
            ))}
          </CardContent>
        </Card>

         {/* Submit Button */}
        <div className="text-center pt-4">
          <Button type="submit" size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3" disabled={isDownloading}>
            {isDownloading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Download className="mr-2 h-5 w-5" />}
            {isDownloading ? 'Generating PDF...' : 'Generate & Download PDF'}
          </Button>
        </div>
      </form>

      {/* Hidden Live Resume Preview Area */}
      {showPreview && (
          <Card className="mt-8 border-primary" >
             <CardHeader>
                 <CardTitle className="text-primary">Live Preview</CardTitle>
                 <CardDescription>This is an approximate preview of your resume layout.</CardDescription>
             </CardHeader>
             <CardContent>
                 <div id="resume-preview-container" ref={resumePreviewRef} className="p-6 bg-white text-black font-sans text-sm border rounded-md shadow-inner max-w-[800px] mx-auto">
                     <ResumePreviewContent formData={formData} renderBulletPoints={renderBulletPoints} />
                 </div>
             </CardContent>
          </Card>
      )}

       {/* Absolute positioned, off-screen div ONLY for PDF generation if preview is hidden */}
       {!showPreview && (
             <div id="resume-preview-offscreen-container" ref={resumePreviewRef} className="p-6 bg-white text-black font-sans text-sm absolute left-[-9999px] top-[-9999px] w-[800px]">
                 <ResumePreviewContent formData={formData} renderBulletPoints={renderBulletPoints} />
             </div>
        )}

    </div>
  );
}


// Separate component for the preview content to avoid duplication
const ResumePreviewContent = ({ formData, renderBulletPoints }: { formData: ResumeFormData, renderBulletPoints: (text: string | undefined) => React.ReactNode }) => {
    return (
        <>
            {/* Inline styles specifically for PDF generation - consider Tailwind classes + @media print */}
             <style>{`
              #resume-preview-content h2 { font-size: 14pt; font-weight: 600; margin-top: 12pt; margin-bottom: 6pt; border-bottom: 1px solid #ccc; padding-bottom: 2pt; color: #008080; font-family: 'Arial', sans-serif; }
              #resume-preview-content h3 { font-size: 11pt; font-weight: 600; margin-bottom: 3pt; font-family: 'Arial', sans-serif; }
              #resume-preview-content p { margin-bottom: 6pt; line-height: 1.3; font-size: 10pt; font-family: 'Arial', sans-serif; }
              #resume-preview-content ul { list-style: disc; margin-left: 18pt; margin-bottom: 6pt; font-size: 10pt; line-height: 1.3; font-family: 'Arial', sans-serif; }
              #resume-preview-content ul li { margin-bottom: 3pt; }
              #resume-preview-content .section { margin-bottom: 12pt; }
              #resume-preview-content .contact-info { text-align: center; margin-bottom: 15pt; border-bottom: 1px solid #eee; padding-bottom: 10pt; }
              #resume-preview-content .contact-info p { margin: 1pt 0; font-size: 10pt; }
              #resume-preview-content .skills-list { display: flex; flex-wrap: wrap; gap: 6pt; margin-top: 4pt; }
              #resume-preview-content .skills-list span { background-color: #e0f2f1; padding: 2pt 6pt; border-radius: 4px; font-size: 9pt; }
              #resume-preview-content .date-range { font-style: italic; color: #555; font-size: 9pt; float: right; }
              #resume-preview-content a { color: #0077b5; text-decoration: none; }
              #resume-preview-content a:hover { text-decoration: underline; }
              #resume-preview-content .item-block { margin-bottom: 10pt; }
            `}</style>
            <div id="resume-preview-content">
              {/* Contact Info */}
              <div className="contact-info">
                <h1 style={{ fontSize: '20pt', fontWeight: 'bold', marginBottom: '4pt', color: '#005a5a' }}>{formData.fullName || "Your Name"}</h1>
                <p style={{ fontSize: '12pt', marginBottom: '6pt', color: '#333' }}>{formData.jobTitle || "Your Job Title"}</p>
                <p>
                  {formData.email && <span>{formData.email}</span>}
                  {formData.phone && <span> | {formData.phone}</span>}
                  {formData.linkedin && <span> | <a href={formData.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn</a></span>}
                  {formData.github && <span> | <a href={formData.github} target="_blank" rel="noopener noreferrer">GitHub</a></span>}
                   {formData.portfolio && <span> | <a href={formData.portfolio} target="_blank" rel="noopener noreferrer">Portfolio</a></span>}
                </p>
              </div>

              {/* Summary */}
              {formData.summary && (
                <div className="section">
                  <h2>Summary</h2>
                  <p>{formData.summary}</p>
                </div>
              )}

              {/* Skills */}
              {formData.skills && formData.skills.length > 0 && formData.skills.some(s => s.name) && (
                <div className="section">
                  <h2>Skills</h2>
                  <div className="skills-list">
                    {formData.skills.map((skill, index) => skill.name ? <span key={index}>{skill.name}</span> : null)}
                  </div>
                </div>
              )}

              {/* Experience */}
              {formData.experience && formData.experience.length > 0 && formData.experience.some(e => e.company || e.position) && (
                <div className="section">
                  <h2>Experience</h2>
                  {formData.experience.map((exp, index) => (exp.company || exp.position || exp.responsibilities) ? (
                    <div key={index} className="item-block">
                      <span className="date-range">{exp.startDate} - {exp.endDate || 'Present'}</span>
                      <h3>{exp.position || "Position"}</h3>
                      <p style={{ fontWeight: 500, marginBottom: '3pt' }}>{exp.company || "Company Name"}</p>
                       {renderBulletPoints(exp.responsibilities)}
                    </div>
                  ) : null)}
                </div>
              )}

              {/* Education */}
              {formData.education && formData.education.length > 0 && formData.education.some(e => e.institution || e.degree) && (
                <div className="section">
                  <h2>Education</h2>
                  {formData.education.map((edu, index) => (edu.institution || edu.degree) ? (
                    <div key={index} className="item-block">
                      <span className="date-range">{edu.startDate} - {edu.endDate}</span>
                      <h3>{edu.degree || "Degree/Major"}</h3>
                       <p style={{ fontWeight: 500, marginBottom: '3pt' }}>{edu.institution || "Institution Name"}</p>
                      {edu.details && <p style={{ fontSize: '9pt', color: '#444' }}>{edu.details}</p>}
                    </div>
                  ) : null)}
                </div>
              )}

              {/* Projects */}
              {formData.projects && formData.projects.length > 0 && formData.projects.some(p=>p.name) && (
                <div className="section">
                  <h2>Projects</h2>
                  {formData.projects.map((proj, index) => proj.name ? (
                    <div key={index} className="item-block">
                       <h3>{proj.name} {proj.link && <a href={proj.link} target="_blank" rel="noopener noreferrer" style={{ fontSize: '9pt', fontWeight: 'normal' }}>(Link)</a>}</h3>
                       {renderBulletPoints(proj.description)}
                    </div>
                  ) : null)}
                </div>
              )}

               {/* Certifications */}
               {formData.certifications && formData.certifications.length > 0 && formData.certifications.some(c=>c.name) && (
                 <div className="section">
                   <h2>Certifications</h2>
                   {formData.certifications.map((cert, index) => cert.name ? (
                     <p key={index} style={{ marginBottom: '4pt' }}>
                        <strong>{cert.name}</strong>
                        {cert.issuer && ` - ${cert.issuer}`}
                        {cert.date && ` (${cert.date})`}
                    </p>
                   ) : null)}
                 </div>
               )}
            </div>
        </>
    );
};

    
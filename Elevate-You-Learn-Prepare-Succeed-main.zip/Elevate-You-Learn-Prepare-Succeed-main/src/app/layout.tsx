import type {Metadata} from 'next';
import { Inter } from 'next/font/google'; // Correct import
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from '@/components/ui/tooltip';

// Configure Inter font
const inter = Inter({
    subsets: ['latin'],
    variable: '--font-inter', // Define CSS variable
});

// Updated Metadata
export const metadata: Metadata = {
  title: 'Elevate You: Learn, Prepare, Succeed',
  description: 'Your ultimate platform for mastering tech skills, building a standout resume, acing interviews, and landing your dream job.',
   keywords: ['learning platform', 'resume builder', 'job recommendations', 'mock interviews', 'career growth', 'tech skills', 'AI', 'machine learning', 'full stack development', 'data science'],
   authors: [{ name: 'AI Assistant & Team' }],
   // Add Open Graph and Twitter card metadata for better sharing
   openGraph: {
       title: 'Elevate You: Learn, Prepare, Succeed',
       description: 'Your ultimate platform for mastering tech skills and advancing your career.',
       type: 'website',
       // url: 'YOUR_DEPLOYED_URL', // Add your deployed URL here
       // images: [ { url: 'YOUR_OG_IMAGE_URL' } ], // Add a link to an Open Graph image
   },
    // twitter: {
   //    card: 'summary_large_image',
   //    title: 'Elevate You: Learn, Prepare, Succeed',
   //    description: 'Master tech skills, build resumes, ace interviews, find jobs.',
   //    // images: ['YOUR_TWITTER_IMAGE_URL'], // Add a link to a Twitter card image
   // },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // Apply the font variable and the Inter font class name to html for global scope
    <html lang="en" className={`${inter.variable} ${inter.className}`} suppressHydrationWarning>
      <body> {/* Body inherits font */}
         <TooltipProvider>
             {children}
             <Toaster />
         </TooltipProvider>
      </body>
    </html>
  );
}

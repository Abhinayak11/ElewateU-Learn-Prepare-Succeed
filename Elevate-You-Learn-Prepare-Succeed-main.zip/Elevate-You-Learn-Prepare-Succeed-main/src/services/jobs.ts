
/**
 * Represents a job listing with relevant details.
 */
export interface JobListing {
  jobTitle: string;
  companyName: string;
  shortDescription: string;
  applyUrl: string;
  location?: string; // Optional location detail
  isRemote?: boolean; // Optional remote flag
  experienceLevel?: string; // Optional experience level
}

/**
 * Represents criteria for filtering job listings.
 */
export interface JobFilter {
  location?: string; // Should always be 'India' in current implementation
  experienceLevel?: string;
  remote?: boolean;
}

/**
 * Asynchronously retrieves mock job listings for India based on search criteria.
 * Filters are applied loosely based on keywords in title/description.
 *
 * @param course The course name (e.g., 'Any', 'Full Stack Development'). Used loosely for filtering.
 * @param skills The skills array (e.g., ['React', 'Node.js']). Used loosely for filtering.
 * @param filter The filter criteria (location must be 'India', others optional).
 * @returns A promise that resolves to an array of JobListing objects (max 6).
 */
export async function getJobListings(
  course: string,
  skills: string[],
  filter: JobFilter
): Promise<JobListing[]> {

  console.log("Filtering mock jobs with:", { course, skills, filter });

  // Extended mock data relevant to India
  const allMockJobs: JobListing[] = [
    {
      jobTitle: 'Software Engineer (Fallback)',
      companyName: 'Sample Tech India',
      shortDescription: 'Develop backend services and APIs for our platform. Based in Bangalore.',
      applyUrl: '#',
      location: 'Bangalore',
      isRemote: false,
      experienceLevel: 'Entry Level',
    },
    {
      jobTitle: 'Frontend Developer - React (Fallback)',
      companyName: 'Sample Solutions Ltd.',
      shortDescription: 'Build responsive user interfaces using React and Tailwind CSS. Join our Hyderabad team.',
      applyUrl: '#',
      location: 'Hyderabad',
      isRemote: false,
      experienceLevel: 'Mid Level',
    },
    {
      jobTitle: 'Data Analyst (Fallback)',
      companyName: 'Sample Insights Hub',
      shortDescription: 'Analyze data, generate reports, and provide insights. Python and SQL required. Location: Pune.',
      applyUrl: '#',
      location: 'Pune',
      isRemote: false,
      experienceLevel: 'Mid Level',
    },
    {
      jobTitle: 'Project Manager - Tech (Fallback)',
      companyName: 'Sample Projects India',
      shortDescription: 'Manage software development projects using Agile methodologies. Based in Mumbai.',
      applyUrl: '#',
      location: 'Mumbai',
      isRemote: false,
      experienceLevel: 'Senior Level',
    },
     {
      jobTitle: 'AI/ML Engineer (Fallback)',
      companyName: 'Sample AI Corp',
      shortDescription: 'Work on cutting-edge machine learning models. Experience with TensorFlow/PyTorch preferred. Chennai.',
      applyUrl: '#',
      location: 'Chennai',
       isRemote: false,
       experienceLevel: 'Mid Level',
    },
     {
      jobTitle: 'Full Stack Developer (Node/React) (Fallback)',
      companyName: 'Sample FullStack Co.',
      shortDescription: 'Develop and maintain both frontend and backend systems. Opportunity in Delhi.',
      applyUrl: '#',
      location: 'Delhi',
       isRemote: false,
       experienceLevel: 'Entry Level',
    },
      {
      jobTitle: 'Cloud Engineer - AWS (Fallback)',
      companyName: 'Sample Cloud Services',
      shortDescription: 'Manage AWS infrastructure, CI/CD pipelines, and monitoring. Noida office.',
      applyUrl: '#',
      location: 'Noida',
       isRemote: false,
       experienceLevel: 'Mid Level',
    },
      {
      jobTitle: 'Remote Software Engineer (India) (Fallback)',
      companyName: 'Sample Remote Works',
      shortDescription: 'Contribute to our core product development remotely from anywhere in India.',
      applyUrl: '#',
      location: 'Remote (India)',
      isRemote: true,
       experienceLevel: 'Senior Level',
    },
      {
      jobTitle: 'Cybersecurity Analyst (Fallback)',
      companyName: 'Secure Solutions India',
      shortDescription: 'Monitor security events, respond to incidents, and perform vulnerability assessments. Based in Bangalore.',
      applyUrl: '#',
       location: 'Bangalore',
       isRemote: false,
       experienceLevel: 'Entry Level',
    },
     {
      jobTitle: 'Senior Frontend Engineer (Remote) (Fallback)',
      companyName: 'Global Tech Remote',
      shortDescription: 'Lead frontend development efforts for our international team. Fully remote within India.',
      applyUrl: '#',
      location: 'Remote (India)',
      isRemote: true,
      experienceLevel: 'Senior Level',
    },
  ];

  // Filtering logic (basic keyword matching)
  let filteredJobs = allMockJobs;

  // Filter by Remote
  if (filter.remote) {
    filteredJobs = filteredJobs.filter(job => job.isRemote || job.location?.toLowerCase().includes('remote'));
  } else {
     // If not explicitly remote, optionally filter out jobs that are clearly remote only
     // filteredJobs = filteredJobs.filter(job => !job.isRemote); // Uncomment if non-remote should exclude remote-only jobs
  }


  // Filter by Experience Level (simple keyword check)
  if (filter.experienceLevel && filter.experienceLevel !== 'Any') {
    const level = filter.experienceLevel.toLowerCase();
    filteredJobs = filteredJobs.filter(job =>
        (job.experienceLevel && job.experienceLevel.toLowerCase().includes(level)) ||
        job.jobTitle.toLowerCase().includes(level) ||
        job.shortDescription.toLowerCase().includes(level)
    );
  }

   // Filter by Course/Skills (very basic keyword check in title/description)
    const courseAndSkillsKeywords = [
        course.toLowerCase(),
        ...skills.map(s => s.toLowerCase())
    ].filter(k => k && k !== 'any' && k !== 'general skills'); // Get relevant keywords

    if (courseAndSkillsKeywords.length > 0) {
        filteredJobs = filteredJobs.filter(job => {
            const jobText = `${job.jobTitle.toLowerCase()} ${job.shortDescription.toLowerCase()}`;
            // Check if at least one keyword matches
            return courseAndSkillsKeywords.some(keyword => jobText.includes(keyword));
        });
    }


  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 300));

  // Return a limited number of results
  return filteredJobs.slice(0, 6);
}
